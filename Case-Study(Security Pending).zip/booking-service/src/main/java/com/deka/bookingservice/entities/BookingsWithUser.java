package com.deka.bookingservice.entities;

public class BookingsWithUser {
	private Bookings booking;
	private User user;

	public BookingsWithUser(Bookings booking, User user) {
		this.booking = booking;
		this.user = user;
	}

	public Bookings getBooking() {
		return booking;
	}

	public void setBooking(Bookings booking) {
		this.booking = booking;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
