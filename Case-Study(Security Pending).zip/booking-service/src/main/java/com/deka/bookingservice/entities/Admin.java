package com.deka.bookingservice.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Admin {

	@JsonIgnore
	private int washpackId;

	private String washPackName;

	private String washPackPrice;

	private String washPackDesc;

	@JsonIgnore
	private int bookingId;

	public int getWashpackId() {
		return washpackId;
	}

	public void setWashpackId(int washpackId) {
		this.washpackId = washpackId;
	}

	public String getWashPackName() {
		return washPackName;
	}

	public void setWashPackName(String washPackName) {
		this.washPackName = washPackName;
	}

	public String getWashPackPrice() {
		return washPackPrice;
	}

	public void setWashPackPrice(String washPackPrice) {
		this.washPackPrice = washPackPrice;
	}

	public String getWashPackDesc() {
		return washPackDesc;
	}

	public void setWashPackDesc(String washPackDesc) {
		this.washPackDesc = washPackDesc;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public Admin(int washpackId, String washPackName, String washPackPrice, String washPackDesc, int bookingId) {
		super();
		this.washpackId = washpackId;
		this.washPackName = washPackName;
		this.washPackPrice = washPackPrice;
		this.washPackDesc = washPackDesc;
		this.bookingId = bookingId;
	}

	public Admin() {
		super();
	}

}
