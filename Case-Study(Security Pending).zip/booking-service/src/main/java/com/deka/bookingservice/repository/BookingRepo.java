package com.deka.bookingservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deka.bookingservice.entities.Bookings;

public interface BookingRepo extends JpaRepository<Bookings, Integer>{

}
