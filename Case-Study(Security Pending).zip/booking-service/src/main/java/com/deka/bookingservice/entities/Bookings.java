package com.deka.bookingservice.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;

@Entity(name = "Booking_Service")
public class Bookings {

	@Id
	@Column(name = "Booking_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookingId;
	@Column(name = "Car_Name")
	private String carName;

	@Column(name = "Schedule_Date")
	private String scheduledate;

	@Column(name = "User_Id")
	@JsonIgnore
	private int uid;
	@Column(name = "Schedule_Time")
	private String scheduleTime;
	@Column(name = "Address")
	private String address;

	@JsonIgnore
	@Column(name = "Wash_Pack_Name")
	private String washPackName;

	@Transient
	@JsonIgnore
	private List<User> user;

	@JsonIgnore
	@Transient
	private List<Washer> washer;

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getScheduledate() {
		return scheduledate;
	}

	public void setScheduledate(String scheduledate) {
		this.scheduledate = scheduledate;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getScheduleTime() {
		return scheduleTime;
	}

	public void setScheduleTime(String scheduleTime) {
		this.scheduleTime = scheduleTime;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getWashPackName() {
		return washPackName;
	}

	public void setWashPackName(String washPackName) {
		this.washPackName = washPackName;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}

	public List<Washer> getWasher() {
		return washer;
	}

	public void setWasher(List<Washer> washer) {
		this.washer = washer;
	}

	public Bookings(int bookingId, String carName, String scheduledate, int uid, String scheduleTime, String address,
			String washPackName, List<User> user, List<Washer> washer) {
		super();
		this.bookingId = bookingId;
		this.carName = carName;
		this.scheduledate = scheduledate;
		this.uid = uid;
		this.scheduleTime = scheduleTime;
		this.address = address;
		this.washPackName = washPackName;
		this.user = user;
		this.washer = washer;
	}

	public Bookings() {
		super();
	}

//	@Transient
//	@Column(name="Washer_Details")
//	private List<Washer> washer =new ArrayList<>();

}
