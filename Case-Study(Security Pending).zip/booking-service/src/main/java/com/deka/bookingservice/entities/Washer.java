package com.deka.bookingservice.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Washer {

	private String wid;
	private String name;
	@JsonIgnore
	private String email;
	@JsonIgnore
	private String password;
	private String status;
	@JsonIgnore
	private String payload;

	public String getWid() {
		return wid;
	}

	public void setWid(String wid) {
		this.wid = wid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public Washer(String wid, String name, String email, String password, String status, String payload) {
		super();
		this.wid = wid;
		this.name = name;
		this.email = email;
		this.password = password;
		this.status = status;
		this.payload = payload;

	}

	public Washer() {
		super();
	}

}
