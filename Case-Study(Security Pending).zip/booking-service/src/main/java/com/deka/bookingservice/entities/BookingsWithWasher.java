package com.deka.bookingservice.entities;

public class BookingsWithWasher {

	private Bookings booking;
	private Washer washer;

	public Bookings getBooking() {
		return booking;
	}

	public void setBooking(Bookings booking) {
		this.booking = booking;
	}

	public Washer getWasher() {
		return washer;
	}

	public void setWasher(Washer washer) {
		this.washer = washer;
	}

	public BookingsWithWasher(Bookings booking, Washer washer) {
		super();
		this.booking = booking;
		this.washer = washer;
	}

	public BookingsWithWasher() {
		super();
	}

}
