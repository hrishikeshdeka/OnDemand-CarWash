package com.deka.bookingservice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deka.bookingservice.config.AdminClientProxy;
import com.deka.bookingservice.config.UserClientProxy;
import com.deka.bookingservice.config.WasherClientProxy;
import com.deka.bookingservice.entities.Admin;
import com.deka.bookingservice.entities.Bookings;
import com.deka.bookingservice.entities.User;
import com.deka.bookingservice.entities.Washer;
import com.deka.bookingservice.exceptions.ResourceNotFoundException;
import com.deka.bookingservice.repository.BookingRepo;
import com.deka.bookingservice.service.BookingService;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingRepo bookingRepository;

	@Autowired
	private UserClientProxy userProxy;

	@Autowired
	private WasherClientProxy washerProxy;

	@Autowired
	private AdminClientProxy adminProxy;

	@Override
	public Bookings create(Bookings bookings) {

		return bookingRepository.save(bookings);
	}

	@Override
	public List<Bookings> getAll() {
		List<Bookings> bookings = bookingRepository.findAll();

		for (Bookings booking : bookings) {
			List<User> users = userProxy.getAllUser();
			booking.setUser(users);
		}

		for (Bookings booking : bookings) {
			List<Washer> washers = washerProxy.getAllWasher();
			booking.setWasher(washers);
		}

		return bookings;
	}

	@Override
	public Bookings getSingle(int bookingId) {

		return bookingRepository.findById(bookingId)
				.orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + bookingId));
	}

	@Override
	public void delete(int bookingId) {

		bookingRepository.deleteById(bookingId);
	}

	@Override
	public Bookings update(int bookingId, Bookings bookings) {
		Bookings existingBooking = bookingRepository.findById(bookings.getBookingId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Booking!"));
		if (existingBooking != null) {
			existingBooking.setCarName(bookings.getCarName());
			existingBooking.setScheduledate(bookings.getScheduledate());

			existingBooking.setUid(bookings.getUid());
			existingBooking.setAddress(bookings.getAddress());
			existingBooking.setUid(bookings.getUid());
			existingBooking.setScheduleTime(bookings.getScheduleTime());
			existingBooking.setWashPackName(bookings.getWashPackName());
			return bookingRepository.save(existingBooking);
		}
		return null;
	}

	@Override
	public User getUserWithBookingId(int bookingId) {
		return userProxy.getUserByBookingId(bookingId);
	}

	@Override
	public Washer getSingleWasherByBookingId(int bookingId) {
		return washerProxy.getSingleWasherByBookingId(bookingId);
	}

	@Override
	public List<Admin> getAdminByWashPackName(String washPackName) {
		return adminProxy.getAdminByWashPackName(washPackName);
	}
//	@Override
//	public User getUserByBookingId(int bookingId) {
//		return userProxy.getUserByBookingId(bookingId);
//	}
}
