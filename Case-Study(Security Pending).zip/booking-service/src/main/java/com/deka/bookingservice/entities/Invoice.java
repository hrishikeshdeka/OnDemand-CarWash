package com.deka.bookingservice.entities;

import java.util.List;

public class Invoice {

	private Bookings booking;
	private User user;
	private Washer washer;
	private List<Admin> washPackDetails;

	public Bookings getBooking() {
		return booking;
	}

	public void setBooking(Bookings booking) {
		this.booking = booking;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Washer getWasher() {
		return washer;
	}

	public void setWasher(Washer washer) {
		this.washer = washer;
	}

	public List<Admin> getWashPackDetails() {
		return washPackDetails;
	}

	public void setWashPackDetails(List<Admin> washPackDetails) {
		this.washPackDetails = washPackDetails;
	}

	public Invoice(Bookings booking, User user, Washer washer, List<Admin> washPackDetails) {
		super();
		this.booking = booking;
		this.user = user;
		this.washer = washer;
		this.washPackDetails = washPackDetails;
	}

	public Invoice() {
		super();
	}

}
