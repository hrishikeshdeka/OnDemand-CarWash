package com.deka.bookingservice.entities;

import java.util.List;

public class BookingsWithWashPackDetails {

	private Bookings booking;
	private List<Admin> washPackDetails;

	public Bookings getBooking() {
		return booking;
	}

	public void setBooking(Bookings booking) {
		this.booking = booking;
	}

	public List<Admin> getWashPackDetails() {
		return washPackDetails;
	}

	public void setWashPackDetails(List<Admin> washPackDetails) {
		this.washPackDetails = washPackDetails;
	}

	public BookingsWithWashPackDetails(Bookings booking, List<Admin> washPackDetails) {
		super();
		this.booking = booking;
		this.washPackDetails = washPackDetails;
	}

	public BookingsWithWashPackDetails() {
		super();
	}

}
