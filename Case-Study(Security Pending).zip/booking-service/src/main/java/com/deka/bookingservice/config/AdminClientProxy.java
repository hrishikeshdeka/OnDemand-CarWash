package com.deka.bookingservice.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deka.bookingservice.entities.Admin;

@FeignClient(name = "Admin-management")
public interface AdminClientProxy {

	@GetMapping("api/admin/washpacks/search/{washPackName}")
	List<Admin> getAdminByWashPackName(@PathVariable("washPackName") String washPackName);

}
