package com.deka.bookingservice.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deka.bookingservice.entities.Admin;
import com.deka.bookingservice.entities.Bookings;
import com.deka.bookingservice.entities.Invoice;
import com.deka.bookingservice.entities.BookingsWithUser;
import com.deka.bookingservice.entities.BookingsWithWashPackDetails;
import com.deka.bookingservice.entities.BookingsWithWasher;
import com.deka.bookingservice.entities.User;
import com.deka.bookingservice.entities.Washer;
import com.deka.bookingservice.service.BookingService;

@RestController
@RequestMapping("/api/bookings")
public class BookingServiceController {

	@Autowired
	private BookingService bookingService;

	@GetMapping("/all")
	public List<Bookings> getAllBookings() {
		return bookingService.getAll();
	}

	@PostMapping("/new")
	public Bookings createBooking(@RequestBody Bookings bookings) {
		return bookingService.create(bookings);
	}

	@PutMapping("/updateBooking/{bookingId}")
	public Bookings updateBooking(@PathVariable int bookingId, @RequestBody Bookings bookings) {
		return bookingService.update(bookingId, bookings);
	}

	@DeleteMapping("/deleteBooking/{bookingId}")
	public void deleteBooking(@PathVariable int bookingId) {
		bookingService.delete(bookingId);
	}

	// fetches user and booking
	@GetMapping("/user/{bookingId}")
	public BookingsWithUser getBookingWithUserDetails(@PathVariable int bookingId) {
		Bookings booking = bookingService.getSingle(bookingId);
		User user = bookingService.getUserWithBookingId(bookingId);

		return new BookingsWithUser(booking, user);
	}

	// fetches washer and booking
	@GetMapping("/washer/{bookingId}")
	public BookingsWithWasher getWasherBookingByBookingId(@PathVariable int bookingId) {
		Washer washer = bookingService.getSingleWasherByBookingId(bookingId);
		Bookings booking = bookingService.getSingle(bookingId);
		return new BookingsWithWasher(booking, washer);
	}

	// fetches washpackDetails and booking
	@GetMapping("washpack/{bookingId}")
	public BookingsWithWashPackDetails getBookingDetailsWithWashPack(@PathVariable int bookingId) {
		Bookings booking = bookingService.getSingle(bookingId);
		List<Admin> washPackDetails = bookingService.getAdminByWashPackName(booking.getWashPackName());
		return new BookingsWithWashPackDetails(booking, washPackDetails);
	}

	// the below code shows the bookings with userId and washer(Invoice)
	@GetMapping("/invoice/{bookingId}")
	public Invoice getBookingWithUserAndWasherDetails(@PathVariable int bookingId) {
		Bookings booking = bookingService.getSingle(bookingId);
		User user = bookingService.getUserWithBookingId(bookingId);
		Washer washer = bookingService.getSingleWasherByBookingId(bookingId);
		List<Admin> admins = bookingService.getAdminByWashPackName(booking.getWashPackName());

		return new Invoice(booking, user, washer, admins);
	}

	
	
	
// the below code shows the bookings with userid
//	@GetMapping("bookings/{bookingId}")
//	public Bookings getSingleBooking(@PathVariable int bookingId) {
//		return bookingService.getSingle(bookingId);
//	}
// the below code shows the bookings with washpack
//	@GetMapping("/washpackDetails/{washPackName}")
//	public List<Admin> getAdminByWashPackName(@PathVariable("washPackName") String washPackName) {
//		return bookingService.getAdminByWashPackName(washPackName);
//	}

}
