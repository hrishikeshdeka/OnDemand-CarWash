package com.deka.washermanagement.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deka.washermanagement.entities.Washer;
import com.deka.washermanagement.exception.ResourceNotFoundException;
import com.deka.washermanagement.repository.WasherRepo;
import com.deka.washermanagement.service.WasherService;

@Service
public class WasherServiceImpl implements WasherService {

	@Autowired
	private WasherRepo washerRepository;

	@Override
	public Washer create(Washer washer) {

		return washerRepository.save(washer);
	}

	@Override
	public List<Washer> getAll() {

		return washerRepository.findAll();
	}

	@Override
	public Washer getSingle(String wid) {

		return washerRepository.findById(wid).orElse(null);
	}

	@Override
	public void delete(String wid) {

		washerRepository.deleteById(wid);

	}

	@Override
	public Washer update(String wid, Washer washer) {

		Washer existingWasher = washerRepository.findById(wid).orElse(null);
		if (existingWasher != null) {
			// Update the properties of the existing washer
			existingWasher.setName(washer.getName());
			existingWasher.setEmail(washer.getEmail());
			existingWasher.setPassword(washer.getPassword());
			existingWasher.setStatus(washer.getStatus());
			existingWasher.setPayload(washer.getPayload());

			return washerRepository.save(existingWasher);
		}
		return null;
	}

	@Override
	public Washer getSingleWasherByBookingId(int bookingId) {
		
		Washer washer = washerRepository.findWasherByBookingId(bookingId);
		if (washer == null) {
			throw new ResourceNotFoundException("User not found with Booking ID: " + bookingId);
		}
		return washer;
	}
	

}
