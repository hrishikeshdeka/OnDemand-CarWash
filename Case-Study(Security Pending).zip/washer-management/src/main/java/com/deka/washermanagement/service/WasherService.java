package com.deka.washermanagement.service;

import java.util.List;

import com.deka.washermanagement.entities.Washer;

public interface WasherService {

	// create
	Washer create(Washer washer);

	// getAll
	List<Washer> getAll();

	// getSingle
	Washer getSingle(String wid);

	// Delete
	void delete(String wid);

	// Update
	Washer update(String wid, Washer washer);
	
	//getSingleWasherByBookingId
	 Washer getSingleWasherByBookingId(int bookingId);

}
