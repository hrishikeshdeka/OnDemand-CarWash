package com.deka.admin.service;

import java.util.List;

import com.deka.admin.entities.Admin;

public interface AdminService {

	// create
	Admin create(Admin admin);

	// getAll
	List<Admin> getAll();

	// getSingle
	Admin getSingle(int washpackId);

	// update
	Admin update(Admin admin);

	// delete
	void delete(int washpackId);
	
	//findByWashPackName
    List<Admin> getByWashPackName(String washPackName);

}
