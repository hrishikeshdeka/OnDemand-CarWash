package com.deka.admin.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deka.admin.entities.Admin;
import com.deka.admin.exceptions.ResourceNotFoundException;
import com.deka.admin.repositories.AdminRepo;
import com.deka.admin.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminRepo adminRepository;

	private static final Logger logger = LoggerFactory.getLogger(AdminServiceImpl.class);

	@Override
	public Admin create(Admin admin) {
		logger.info("Creating user: {}", admin);
		return adminRepository.save(admin);
	}

	@Override
	public List<Admin> getAll() {
		logger.info("Retrieving all users");
		return adminRepository.findAll();
	}

	@Override
	public Admin getSingle(int washpackId) {
		return adminRepository.findById(washpackId).orElse(null);
	}

	@Override
	public Admin update(Admin admin) {
		logger.info("Updating user: {}", admin);
		Admin existingAdmin = adminRepository.findById(admin.getWashpackId()).orElseThrow(() -> {
			logger.error("User not found with ID: {}", admin.getWashpackId());
			return new ResourceNotFoundException("User not found with ID: " + admin.getWashpackId());
		});

		existingAdmin.setWashPackName(admin.getWashPackName());
		existingAdmin.setWashPackPrice(admin.getWashPackPrice());
		existingAdmin.setWashPackDesc(admin.getWashPackDesc());
		existingAdmin.setBookingId(admin.getBookingId());

		return adminRepository.save(existingAdmin);
	}

	@Override
	public void delete(int washpackId) {
		logger.info("Deleting user with ID: {}", washpackId);
		adminRepository.deleteById(washpackId);
	}

	@Override
	public List<Admin> getByWashPackName(String washPackName) {
		return adminRepository.findByWashPackName(washPackName);
	
	}

}
