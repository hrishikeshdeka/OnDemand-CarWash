package com.deka.admin.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deka.admin.entities.Admin;

public interface AdminRepo extends JpaRepository<Admin, Integer> {

	public List<Admin> findByWashPackName(String washPackName);
}
