package com.deka.admin.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Wash_Packs")
public class Admin {

	@Id
	@Column(name = "Washpack_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int washpackId;
	@Column(name = "Washpack_Name")
	private String washPackName;
	@Column(name = "Washpack_Price")
	private String washPackPrice;
	@Column(name = "Washpack_Desc")
	private String washPackDesc;

	@Column(name = "Booking_ID")
	private int bookingId;

	public int getWashpackId() {
		return washpackId;
	}

	public void setWashpackId(int washpackId) {
		this.washpackId = washpackId;
	}

	public String getWashPackName() {
		return washPackName;
	}

	public void setWashPackName(String washPackName) {
		this.washPackName = washPackName;
	}

	public String getWashPackPrice() {
		return washPackPrice;
	}

	public void setWashPackPrice(String washPackPrice) {
		this.washPackPrice = washPackPrice;
	}

	public String getWashPackDesc() {
		return washPackDesc;
	}

	public void setWashPackDesc(String washPackDesc) {
		this.washPackDesc = washPackDesc;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public Admin(int washpackId, String washPackName, String washPackPrice, String washPackDesc, int bookingId) {
		super();
		this.washpackId = washpackId;
		this.washPackName = washPackName;
		this.washPackPrice = washPackPrice;
		this.washPackDesc = washPackDesc;
		this.bookingId = bookingId;
	}

	public Admin() {
		super();
	}

}
