package com.deka.admin.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deka.admin.entities.Admin;
import com.deka.admin.service.AdminService;

@RestController
@RequestMapping("/api/admin/")
public class AdminController {

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private AdminService adminService;

	@GetMapping("washpacks/all")
	public List<Admin> getAllUser() {
		logger.info("GET /admin/washpacks/all");
		return adminService.getAll();

	}

	@GetMapping("washpacks/{washpackId}")
	public Admin getAdminById(@PathVariable int washpackId) {
		logger.info("GET /admin/washpacks/" + washpackId);
		return adminService.getSingle(washpackId);
	}

	@PostMapping("washpacks/add")
	public Admin createUser(@RequestBody Admin admin) {
		logger.info("POST admin/washpacks/add");
		return adminService.create(admin);
	}

	@PutMapping("washpacks/{washpackId}")
	public Admin updateUser(@PathVariable int washpackId, @RequestBody Admin admin) {
		logger.info("PUT admin/washpacks/" + washpackId);
		admin.setWashpackId(washpackId);
		return adminService.update(admin);
	}

	@DeleteMapping("washpacks/{washpackId}")
	public void deleteUser(@PathVariable int washpackId) {
		logger.info("DELETE admin/washpacks/" + washpackId);
		adminService.delete(washpackId);
	}

	@GetMapping("washpacks/search/{washPackName}")
	public List<Admin> getAdminByWashPackName(@PathVariable("washPackName") String washPackName) {
		return adminService.getByWashPackName(washPackName);
	}
	
	
	

}
