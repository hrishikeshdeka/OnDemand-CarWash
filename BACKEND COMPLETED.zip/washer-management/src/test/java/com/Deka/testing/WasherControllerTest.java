package com.Deka.testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.security.controllers.WasherController;
import com.security.model.Washer;
import com.security.service.WasherService;

class WasherControllerTest {

    @Mock
    private WasherService washerService;

    @InjectMocks
    private WasherController washerController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateWasher() {
        Washer washer = new Washer();
        when(washerService.create(any(Washer.class))).thenReturn(washer);
        Washer createdWasher = washerController.createUser(washer);
        assertEquals(washer, createdWasher);
        verify(washerService).create(washer);
    }

    @Test
    void testGetAllWashers() {
        List<Washer> washerList = new ArrayList<>();
        washerList.add(new Washer());
        when(washerService.getAll()).thenReturn(washerList);
        List<Washer> retrievedWashers = washerController.getAllWashers();
        assertEquals(washerList, retrievedWashers);
        verify(washerService).getAll();
    }

    @Test
    void testGetWasher() {
        int washerId = 1;
        Washer washer = new Washer();
        when(washerService.getSingle(washerId)).thenReturn(washer);
        Washer retrievedWasher = washerController.getWasher(washerId);
        assertEquals(washer, retrievedWasher);
        verify(washerService).getSingle(washerId);
    }

    @Test
    void testDeleteUser() {
        int washerId = 1;
        washerController.deleteUser(washerId);
        verify(washerService).delete(washerId);
    }

    @Test
    void testUpdateUser() {
        int washerId = 1;
        Washer washer = new Washer();
        when(washerService.update(any(Washer.class))).thenReturn(washer);
        Washer updatedWasher = washerController.updateUser(washerId, washer);
        assertEquals(washer, updatedWasher);
        verify(washerService).update(washer);
    }

    @Test
    void testGetWasherByEmail() {
        String email = "test@example.com";
        Optional<Washer> washer = Optional.of(new Washer());
        when(washerService.findByEmail(email)).thenReturn(washer);
        Optional<Washer> retrievedWasher = washerController.getWasherByEmail(email);
        assertEquals(washer, retrievedWasher);
        verify(washerService).findByEmail(email);
    }
}
