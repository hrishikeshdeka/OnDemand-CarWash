package com.security.auth;

import java.util.Optional;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.security.config.JwtService;
import com.security.model.Role;
import com.security.model.UserRepository;
import com.security.model.Washer;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthenticationService {
	private final UserRepository repository;

	private final PasswordEncoder passwordEncoder;
	private final JwtService jwtService;
	private final AuthenticationManager authenticationManager;

	public AuthenticationResponse register(RegisterRequest request) {
		var user = Washer.builder().firstname(request.getFirstname()).lastname(request.getLastname())
				.email(request.getEmail()).phone(request.getPhone())
				.password(passwordEncoder.encode(request.getPassword())).status(request.getStatus()).role(Role.WASHER)
				.build();
		repository.save(user);
		var jwtToken = jwtService.generateToken(user);

		return AuthenticationResponse.builder().token(jwtToken)

				.build();
	}

	public AuthenticationResponse authenticate(AuthenticationRequest request) {
		authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
		var user = repository.findByEmail(request.getEmail()).orElseThrow();
		var jwtToken = jwtService.generateToken(user);

		return AuthenticationResponse.builder().token(jwtToken)

				.build();
	}

	public void updateWasherById(Integer id, UpdatedWasherRequest request) {
		Optional<Washer> optionalWasher = repository.findById(id);

		if (optionalWasher.isPresent()) {
			Washer washer = optionalWasher.get();

			washer.setFirstname(request.getFirstname());
			washer.setLastname(request.getLastname());
			washer.setEmail(request.getEmail());
			washer.setPhone(request.getPhone());
			washer.setStatus(request.getStatus());
			// If you want to update the password, you can do so like this:
			if (request.getPassword() != null) {
				String encodedPassword = passwordEncoder.encode(request.getPassword());
				washer.setPassword(encodedPassword);
			}

			repository.save(washer);
		} else {

		}
	}

	public void updateWasherStatusById(Integer id, String status) {
		Optional<Washer> optionalWasher = repository.findById(id);

		if (optionalWasher.isPresent()) {
			Washer washer = optionalWasher.get();
			washer.setStatus(status);
			repository.save(washer);
		} else {
			// Handle the case when the washer with the given ID is not found
			throw new RuntimeException("Washer not found");
		}
	}

}
