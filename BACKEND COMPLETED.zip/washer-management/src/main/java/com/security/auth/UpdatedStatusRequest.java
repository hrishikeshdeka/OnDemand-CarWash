package com.security.auth;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdatedStatusRequest {
	
	  private String status;

}
