package com.security.auth;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@AllArgsConstructor
@Setter
@NoArgsConstructor
@Builder
public class UpdatedWasherRequest {

	private String firstname;

	private String lastname;
	private String email;
	private String password;
	private String status;
	private Long phone;

}
