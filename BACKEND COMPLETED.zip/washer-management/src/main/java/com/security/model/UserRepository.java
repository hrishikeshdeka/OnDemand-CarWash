package com.security.model;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface UserRepository extends JpaRepository<Washer, Integer> {

	Optional<Washer> findByEmail(String email);
	
	@Modifying
	@Transactional
	@Query("UPDATE Washer w SET w.firstname = :firstname, w.lastname = :lastname, w.email = :email, w.password = :password WHERE w.id = :id")
	void updateWasher(@Param("id") Integer id, @Param("firstname") String firstname, @Param("lastname") String lastname,
			@Param("email") String email, @Param("password") String password);
	

}
