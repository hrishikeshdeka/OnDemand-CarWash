package com.security.model;

//@RequiredArgsConstructor
public enum Role {

	WASHER, ADMIN
}
