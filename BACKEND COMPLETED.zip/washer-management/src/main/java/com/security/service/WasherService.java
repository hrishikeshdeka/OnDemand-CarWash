package com.security.service;

import java.util.List;
import java.util.Optional;

import com.security.model.Washer;

public interface WasherService {

	Washer create(Washer washer);

	List<Washer> getAll();

	Washer getSingle(Integer id);

	void delete(Integer id);

	Washer update(Washer washer);

	Optional<Washer> findByEmail(String email);

}
