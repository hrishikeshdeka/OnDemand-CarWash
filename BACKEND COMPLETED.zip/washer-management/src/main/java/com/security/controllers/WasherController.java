package com.security.controllers;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.security.model.Washer;
import com.security.service.WasherService;

@RestController
@RequestMapping("api/washer")
@CrossOrigin(origins = "http://localhost:3000")
public class WasherController {

	@Autowired
	private WasherService washerService;

	private static final Logger logger = LoggerFactory.getLogger(WasherController.class);

	@PostMapping("/create")
	public Washer createUser(@RequestBody Washer washer) {
		Washer createdWasher = washerService.create(washer);
		logger.info("Created a new washer: {}", createdWasher);
		return createdWasher;
	}

	@GetMapping("/all")
	public List<Washer> getAllWashers() {
		List<Washer> washers = washerService.getAll();
		return washers;
	}

	@GetMapping("/{id}")
	public Washer getWasher(@PathVariable Integer id) {
		Washer washer = washerService.getSingle(id);
		if (washer != null) {
			logger.info("Retrieved washer with ID {}: {}", id, washer);
			return washer;
		} else {
			logger.warn("Washer with ID {} not found", id);
			return null;
		}
	}

	@DeleteMapping("/{id}")
	public void deleteUser(@PathVariable Integer id) {
		washerService.delete(id);
		logger.info("Deleted washer with ID: {}", id);
	}

	@PutMapping("/edit/{id}")
	public Washer updateUser(@PathVariable Integer id, @RequestBody Washer washer) {
		washer.setId(id);
		Washer updatedWasher = washerService.update(washer);
		logger.info("Updated washer with ID {}: {}", id, updatedWasher);
		return updatedWasher;
	}

	@GetMapping("/email/{email}")
	public Optional<Washer> getWasherByEmail(@PathVariable String email) {
		Optional<Washer> washer = washerService.findByEmail(email);
		if (washer.isPresent()) {
			logger.info("Retrieved washer with email {}: {}", email, washer.get());
			return washer;
		} else {
			logger.warn("Washer with email {} not found", email);
			return Optional.empty();
		}

	}
}
