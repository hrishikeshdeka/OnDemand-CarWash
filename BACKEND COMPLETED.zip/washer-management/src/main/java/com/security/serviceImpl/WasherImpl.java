package com.security.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.security.model.Washer;
import com.security.model.UserRepository;
import com.security.service.WasherService;

@Service
public class WasherImpl implements WasherService {

	@Autowired
	private UserRepository washerRepository;

	@Override
	public Washer create(Washer washer) {

		return washerRepository.save(washer);
	}

	@Override
	public List<Washer> getAll() {
		// TODO Auto-generated method stub
		return washerRepository.findAll();
	}

	@Override
	public Washer getSingle(Integer id) {
		// TODO Auto-generated method stub
		return washerRepository.findById(id).orElse(null);
	}

	@Override
	public void delete(Integer id) {
		washerRepository.deleteById(id);

	}

	@Override
	public Washer update(Washer washer) {
		Washer existingUser = getSingle(washer.getId());
		if (existingUser != null) {
			existingUser.setFirstname(washer.getFirstname());
			existingUser.setLastname(washer.getLastname());
			existingUser.setEmail(washer.getEmail());
			existingUser.setPassword(washer.getPassword());
			existingUser.setStatus(washer.getStatus());
			return existingUser;
		}
		return null;
	}

	@Override
	public Optional<Washer> findByEmail(String email) {
		return washerRepository.findByEmail(email);
	}

}
