package com.deka.adminmanagement.proxies;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.deka.adminmanagement.entities.BookingResponse;
import com.deka.adminmanagement.entities.Bookings;

@FeignClient(name = "BOOKING-MANAGEMENT")
public interface BookingClientProxy {

	@GetMapping("api/booking/get/{id}")
	Bookings getBookingById(@PathVariable("id") int id);

	@GetMapping("api/booking/get/all")
	List<Bookings> getAllBookings();

	@PutMapping("api/booking/edit/{id}")
	Bookings updateBooking(@PathVariable("id") int id, @RequestBody Bookings booking);

	@DeleteMapping("api/booking/delete/{id}")
	void deleteBooking(@PathVariable("id") int id);

	@PostMapping("api/booking/create/{id}")
	Bookings createBooking(@PathVariable("id") Integer id, @RequestBody Bookings booking);

	@PutMapping("api/booking/{bookingId}/assign-washer")
	ResponseEntity<String> assignRandomWasher(@PathVariable("bookingId") int bookingId);

	@GetMapping("api/booking/BookingWasher/{id}")
	BookingResponse getBookingWithWasher(@PathVariable("id") int id);

	@GetMapping("api/booking/user/bookings/{userId}")
	List<Bookings> getBookingsByUserId(@PathVariable("userId") Integer userId);

}
