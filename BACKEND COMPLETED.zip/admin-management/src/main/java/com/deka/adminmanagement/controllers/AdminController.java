package com.deka.adminmanagement.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deka.adminmanagement.entities.Admin;
import com.deka.adminmanagement.entities.BookingResponse;
import com.deka.adminmanagement.entities.Bookings;
import com.deka.adminmanagement.entities.User;
import com.deka.adminmanagement.entities.Washer;
import com.deka.adminmanagement.service.AdminService;

@RestController
@RequestMapping("api/admin")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminController {

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private AdminService adminService;

	@GetMapping("washpacks/all")
	public List<Admin> getAllUser() {
		logger.info("GET /admin/washpacks/all");
		return adminService.getAll();

	}

	@GetMapping("washpacks/{washpackId}")
	public Admin getAdminById(@PathVariable String washpackId) {
		logger.info("GET /admin/washpacks/{}", washpackId);
		return adminService.getSingle(washpackId);
	}

	@PostMapping("washpacks/add")
	public Admin createUser(@RequestBody Admin admin) {
		logger.info("POST /admin/washpacks/add");
		return adminService.create(admin);
	}

	@PutMapping("washpacks/{washpackId}")
	public Admin updateUser(@PathVariable String washpackId, @RequestBody Admin admin) {
		logger.info("PUT /admin/washpacks/{}", washpackId);
		admin.setWashpackId(washpackId);
		return adminService.update(admin);
	}

	@DeleteMapping("washpacks/delete/{washpackId}")
	public void deleteUser(@PathVariable String washpackId) {
		logger.info("DELETE /admin/washpacks/{}", washpackId);
		adminService.delete(washpackId);
	}

	@GetMapping("washpacks/search/{washPackName}")
	public List<Admin> getAdminByWashPackName(@PathVariable("washPackName") String washPackName) {
		return adminService.getByWashPackName(washPackName);
	}

	// USER PROXIES

	@DeleteMapping("user/delete/{id}")
	public void deleteUser(@PathVariable Integer id) {
		adminService.deleteUser(id);
		logger.info("Deleted user with ID: {}", id);
	}

	@PutMapping("user/edit/{id}")
	public User updateUser(@PathVariable Integer id, @RequestBody User user) {
		User updatedUser = adminService.updateUser(id, user);
		logger.info("Updated user with ID {}: {}", id, updatedUser);
		return updatedUser;
	}

	@GetMapping("user/{id}")
	public User getUser(@PathVariable Integer id) {
		User user = adminService.getUser(id);
		if (user != null) {
			logger.info("Retrieved user with ID {}: {}", id, user);
		} else {
			logger.warn("User with ID {} not found", id);
		}
		return user;
	}

	@GetMapping("user/all")
	public List<User> getAllUsers() {
		List<User> users = adminService.getAllUsers();
		logger.info("Retrieved all users");
		return users;
	}

	// WASHER PROXIES

	@GetMapping("/washer/all")
	public List<Washer> getAllWashers() {
		List<Washer> washers = adminService.getAllWashers();
		logger.info("Retrieved all washers");
		return washers;
	}

	@GetMapping("/washer/{id}")
	public Washer getWasher(@PathVariable Integer id) {
		Washer washer = adminService.getWasher(id);
		if (washer != null) {
			logger.info("Retrieved washer with ID {}: {}", id);
		} else {
			logger.warn("Washer with ID {} not found", id);
		}
		return washer;
	}

	@DeleteMapping("/washers/delete/{id}")
	public void deleteWasher(@PathVariable Integer id) {
		adminService.deleteWasher(id);
		logger.info("Deleted washer with ID: {}", id);
	}

	@PutMapping("/washers/edit/{id}")
	public Washer updateWasher(@PathVariable Integer id, @RequestBody Washer washer) {
		Washer updatedWasher = adminService.updateWasher(id, washer);
		logger.info("Updated washer with ID {}: {}", id);
		return updatedWasher;
	}

	// Booking PROXIES

	@GetMapping("/bookings/{id}")
	public Bookings getBookingById(@PathVariable int id) {
		Bookings booking = adminService.getBookingById(id);
		if (booking != null) {
			logger.info("Retrieved booking with ID {}: {}", id, booking);
		} else {
			logger.warn("Booking with ID {} not found", id);
		}
		return booking;
	}

	@GetMapping("/bookings/all")
	public List<Bookings> getAllBookings() {
		List<Bookings> bookings = adminService.getAllBookings();
		logger.info("Retrieved all bookings");
		return bookings;
	}

	@PutMapping("/bookings/edit/{id}")
	public Bookings updateBooking(@PathVariable int id, @RequestBody Bookings booking) {
		Bookings updatedBooking = adminService.updateBooking(id, booking);
		logger.info("Updated booking with ID {}: {}", id);
		return updatedBooking;
	}

	@DeleteMapping("/bookings/delete/{id}")
	public void deleteBooking(@PathVariable int id) {
		adminService.deleteBooking(id);
		logger.info("Deleted booking with ID: {}", id);
	}

	@PostMapping("/bookings/create/{id}")
	public Bookings createBooking(@PathVariable Integer id, @RequestBody Bookings booking) {
		Bookings createdBooking = adminService.createBooking(id, booking);
		logger.info("Created a new booking: {}", createdBooking);
		return createdBooking;
	}

	@PutMapping("/bookings/{bookingId}/assign-washer")
	public String assignRandomWasher(@PathVariable int bookingId) {
		adminService.assignRandomWasher(bookingId);
		logger.info("Assigned a random washer to booking with ID: {}", bookingId);
		return "Washer assigned successfully";
	}

	@GetMapping("/bookings/BookingWasher/{id}")
	public BookingResponse getBookingWithWasher(@PathVariable int id) {
		BookingResponse bookingResponse = adminService.getBookingWithWasher(id);
		if (bookingResponse != null) {
			logger.info("Retrieved booking with washer information for ID {}: {}", id, bookingResponse);
		} else {
			logger.warn("Booking with ID {} not found", id);
		}
		return bookingResponse;
	}

	@GetMapping("/bookings/user/{userId}")
	public List<Bookings> getBookingsByUserId(@PathVariable Integer userId) {
		return adminService.getBookingsByUserId(userId);
	}

}
