package com.deka.adminmanagement.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Bookings {

	private int id;
	private String carName;
	private String address;
	private String packName;

	private String date;

	private String time;
	private Integer userId;
	private Integer washerId;
	
	private String bookingStatus="NOT CONFIRMED";

}
