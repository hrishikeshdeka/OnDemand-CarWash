package com.deka.adminmanagement.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.deka.adminmanagement.entities.Admin;

public interface AdminRepository extends MongoRepository<Admin, String>{

	public List<Admin> findByWashPackName(String washPackName);
}
