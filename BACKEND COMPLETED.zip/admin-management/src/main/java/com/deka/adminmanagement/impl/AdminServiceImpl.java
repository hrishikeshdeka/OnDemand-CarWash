package com.deka.adminmanagement.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.deka.adminmanagement.entities.Admin;
import com.deka.adminmanagement.entities.BookingResponse;
import com.deka.adminmanagement.entities.Bookings;
import com.deka.adminmanagement.entities.User;
import com.deka.adminmanagement.entities.Washer;
import com.deka.adminmanagement.exceptions.ResourceNotFoundException;
import com.deka.adminmanagement.proxies.BookingClientProxy;
import com.deka.adminmanagement.proxies.UserClientProxy;
import com.deka.adminmanagement.proxies.WasherClientProxy;
import com.deka.adminmanagement.repositories.AdminRepository;
import com.deka.adminmanagement.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminRepository adminRepository;

	@Autowired
	private UserClientProxy userProxy;
	@Autowired
	private WasherClientProxy washerProxy;

	@Autowired
	private BookingClientProxy bookingProxy;

	private final Logger logger = LoggerFactory.getLogger(AdminServiceImpl.class);

	@Override
	public Admin create(Admin admin) {
		logger.info("Creating user: {}", admin);
		return adminRepository.save(admin);
	}

	@Override
	public List<Admin> getAll() {
		logger.info("Retrieving all users");
		return adminRepository.findAll();
	}

	@Override
	public Admin getSingle(String washpackId) {
		return adminRepository.findById(washpackId).orElse(null);
	}

	@Override
	public Admin update(Admin admin) {
		logger.info("Updating user: {}", admin);
		Admin existingAdmin = adminRepository.findById(admin.getWashpackId()).orElseThrow(() -> {
			logger.error("User not found with ID: {}", admin.getWashpackId());
			return new ResourceNotFoundException("User not found with ID: " + admin.getWashpackId());
		});

		existingAdmin.setWashPackName(admin.getWashPackName());
		existingAdmin.setWashPackPrice(admin.getWashPackPrice());
		existingAdmin.setWashPackDesc(admin.getWashPackDesc());

		return adminRepository.save(existingAdmin);
	}

	@Override
	public void delete(String washpackId) {
		logger.info("Deleting user with ID: {}", washpackId);
		adminRepository.deleteById(washpackId);
	}

	@Override
	public List<Admin> getByWashPackName(String washPackName) {
		return adminRepository.findByWashPackName(washPackName);

	}

	// USER ProXIES
	@Override
	public ResponseEntity<Void> deleteUser(@PathVariable Integer id) {
		return userProxy.deleteUser(id);
	}

	@Override
	public User updateUser(@PathVariable Integer id, @RequestBody User user) {
		return userProxy.updateUser(id, user);
	}

	@Override
	public User getUser(@PathVariable Integer id) {
		return userProxy.getUser(id);
	}

	@Override
	public List<User> getAllUsers() {
		return userProxy.getAllUsers();
	}

	// Washer PROXIES
	@Override
	public List<Washer> getAllWashers() {

		return washerProxy.getAllWashers();
	}

	@Override
	public Washer getWasher(Integer id) {

		return washerProxy.getWasher(id);
	}

	@Override
	public void deleteWasher(Integer id) {

		washerProxy.deleteWasher(id);

	}

	@Override
	public Washer updateWasher(Integer id, Washer washer) {

		return washerProxy.updateWasher(id, washer);
	}

	// Booking Proxies

	@Override
	public Bookings getBookingById(int id) {
		return bookingProxy.getBookingById(id);
	}

	@Override
	public List<Bookings> getAllBookings() {
		return bookingProxy.getAllBookings();
	}

	@Override
	public Bookings updateBooking(int id, Bookings booking) {
		return bookingProxy.updateBooking(id, booking);
	}

	@Override
	public void deleteBooking(int id) {
		bookingProxy.deleteBooking(id);
	}

	@Override
	public Bookings createBooking(Integer id, Bookings booking) {
		return bookingProxy.createBooking(id, booking);
	}

	@Override
	public ResponseEntity<String> assignRandomWasher(int bookingId) {
		return bookingProxy.assignRandomWasher(bookingId);
	}

	@Override
	public BookingResponse getBookingWithWasher(int id) {
		return bookingProxy.getBookingWithWasher(id);
	}

	 @Override
	    public List<Bookings> getBookingsByUserId(Integer userId) {
	        return bookingProxy.getBookingsByUserId(userId);
	    }

}
