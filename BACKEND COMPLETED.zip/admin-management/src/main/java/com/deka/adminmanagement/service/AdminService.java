package com.deka.adminmanagement.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.deka.adminmanagement.entities.Admin;
import com.deka.adminmanagement.entities.BookingResponse;
import com.deka.adminmanagement.entities.Bookings;
import com.deka.adminmanagement.entities.User;
import com.deka.adminmanagement.entities.Washer;

public interface AdminService {

	// create
	Admin create(Admin admin);

	// getAll
	List<Admin> getAll();

	// getSingle
	Admin getSingle(String washpackId);

	// update
	Admin update(Admin admin);

	// delete
	void delete(String washpackId);

	// findByWashPackName
	List<Admin> getByWashPackName(String washPackName);

	// User Services
	ResponseEntity<Void> deleteUser(Integer id);

	User updateUser(Integer id, User user);

	User getUser(Integer id);

	List<User> getAllUsers();

	// Washer Services
	List<Washer> getAllWashers();

	Washer getWasher(Integer id);

	void deleteWasher(Integer id);

	Washer updateWasher(Integer id, Washer washer);

	// Booking Services

	Bookings getBookingById(int id);

	List<Bookings> getAllBookings();

	Bookings updateBooking(int id, Bookings booking);

	void deleteBooking(int id);

	Bookings createBooking(Integer id, Bookings booking);

	ResponseEntity<String> assignRandomWasher(int bookingId);

	BookingResponse getBookingWithWasher(int id);

	List<Bookings> getBookingsByUserId(Integer userId);

}
