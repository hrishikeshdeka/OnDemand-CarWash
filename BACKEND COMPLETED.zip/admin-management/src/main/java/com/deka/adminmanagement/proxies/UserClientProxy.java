package com.deka.adminmanagement.proxies;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.deka.adminmanagement.entities.User;

@FeignClient(name = "USER-MANAGEMENT")
public interface UserClientProxy {

	@DeleteMapping("api/user/delete/{id}")
	ResponseEntity<Void> deleteUser(@PathVariable Integer id);

	@PutMapping("api/user/edit/{id}")
	User updateUser(@PathVariable Integer id, @RequestBody User user);

	@GetMapping("api/user/{id}")
	User getUser(@PathVariable Integer id);

	@GetMapping("api/user/all")
	List<User> getAllUsers();

}
