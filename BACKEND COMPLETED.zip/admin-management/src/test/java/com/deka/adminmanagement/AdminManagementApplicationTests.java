package com.deka.adminmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.deka.adminmanagement.controllers.AdminController;
import com.deka.adminmanagement.entities.Admin;
import com.deka.adminmanagement.entities.BookingResponse;
import com.deka.adminmanagement.entities.Bookings;
import com.deka.adminmanagement.entities.User;
import com.deka.adminmanagement.entities.Washer;
import com.deka.adminmanagement.service.AdminService;

class AdminControllerTest {

    @Mock
    private AdminService adminService;

    @InjectMocks
    private AdminController adminController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllUser() {
        List<Admin> userList = new ArrayList<>();
        userList.add(new Admin());
        when(adminService.getAll()).thenReturn(userList);
        List<Admin> retrievedUsers = adminController.getAllUser();
        assertEquals(userList, retrievedUsers);
        verify(adminService).getAll();
    }

    @Test
    void testGetAdminById() {
        String washpackId = "1";
        Admin admin = new Admin();
        when(adminService.getSingle(washpackId)).thenReturn(admin);
        Admin retrievedAdmin = adminController.getAdminById(washpackId);
        assertEquals(admin, retrievedAdmin);
        verify(adminService).getSingle(washpackId);
    }

    @Test
    void testCreateUser() {
        Admin admin = new Admin();
        when(adminService.create(any(Admin.class))).thenReturn(admin);
        Admin createdAdmin = adminController.createUser(admin);
        assertEquals(admin, createdAdmin);
        verify(adminService).create(admin);
    }

    @Test
    void testUpdateUser() {
        String washpackId = "1";
        Admin admin = new Admin();
        when(adminService.update(any(Admin.class))).thenReturn(admin);
        Admin updatedAdmin = adminController.updateUser(washpackId, admin);
        assertEquals(admin, updatedAdmin);
        verify(adminService).update(admin);
    }

    @Test
    void testDeleteUser() {
        String washpackId = "1";
        adminController.deleteUser(washpackId);
        verify(adminService).delete(washpackId);
    }

    @Test
    void testGetAdminByWashPackName() {
        String washPackName = "Test";
        List<Admin> adminList = new ArrayList<>();
        adminList.add(new Admin());
        when(adminService.getByWashPackName(washPackName)).thenReturn(adminList);
        List<Admin> retrievedAdmins = adminController.getAdminByWashPackName(washPackName);
        assertEquals(adminList, retrievedAdmins);
        verify(adminService).getByWashPackName(washPackName);
    }

    @Test
    void testDeleteUserById() {
        Integer userId = 1;
        adminController.deleteUser(userId);
        verify(adminService).deleteUser(userId);
    }

    @Test
    void testUpdateUserById() {
        Integer userId = 1;
        User user = new User();
        when(adminService.updateUser(eq(userId), any(User.class))).thenReturn(user);
        User updatedUser = adminController.updateUser(userId, user);
        assertEquals(user, updatedUser);
        verify(adminService).updateUser(userId, user);
    }

    @Test
    void testGetUser() {
        Integer userId = 1;
        User user = new User();
        when(adminService.getUser(userId)).thenReturn(user);
        User retrievedUser = adminController.getUser(userId);
        assertEquals(user, retrievedUser);
        verify(adminService).getUser(userId);
    }

    @Test
    void testGetAllUsers() {
        List<User> userList = new ArrayList<>();
        userList.add(new User());
        when(adminService.getAllUsers()).thenReturn(userList);
        List<User> retrievedUsers = adminController.getAllUsers();
        assertEquals(userList, retrievedUsers);
        verify(adminService).getAllUsers();
    }

    @Test
    void testGetAllWashers() {
        List<Washer> washerList = new ArrayList<>();
        washerList.add(new Washer());
        when(adminService.getAllWashers()).thenReturn(washerList);
        List<Washer> retrievedWashers = adminController.getAllWashers();
        assertEquals(washerList, retrievedWashers);
        verify(adminService).getAllWashers();
    }

    @Test
    void testGetWasher() {
        Integer washerId = 1;
        Washer washer = new Washer();
        when(adminService.getWasher(washerId)).thenReturn(washer);
        Washer retrievedWasher = adminController.getWasher(washerId);
        assertEquals(washer, retrievedWasher);
        verify(adminService).getWasher(washerId);
    }

    @Test
    void testDeleteWasher() {
        Integer washerId = 1;
        adminController.deleteWasher(washerId);
        verify(adminService).deleteWasher(washerId);
    }

    @Test
    void testUpdateWasher() {
        Integer washerId = 1;
        Washer washer = new Washer();
        when(adminService.updateWasher(eq(washerId), any(Washer.class))).thenReturn(washer);
        Washer updatedWasher = adminController.updateWasher(washerId, washer);
        assertEquals(washer, updatedWasher);
        verify(adminService).updateWasher(washerId, washer);
    }

    @Test
    void testGetBookingById() {
        int bookingId = 1;
        Bookings booking = new Bookings();
        when(adminService.getBookingById(bookingId)).thenReturn(booking);
        Bookings retrievedBooking = adminController.getBookingById(bookingId);
        assertEquals(booking, retrievedBooking);
        verify(adminService).getBookingById(bookingId);
    }

    @Test
    void testGetAllBookings() {
        List<Bookings> bookingList = new ArrayList<>();
        bookingList.add(new Bookings());
        when(adminService.getAllBookings()).thenReturn(bookingList);
        List<Bookings> retrievedBookings = adminController.getAllBookings();
        assertEquals(bookingList, retrievedBookings);
        verify(adminService).getAllBookings();
    }

    @Test
    void testUpdateBooking() {
        int bookingId = 1;
        Bookings booking = new Bookings();
        when(adminService.updateBooking(eq(bookingId), any(Bookings.class))).thenReturn(booking);
        Bookings updatedBooking = adminController.updateBooking(bookingId, booking);
        assertEquals(booking, updatedBooking);
        verify(adminService).updateBooking(bookingId, booking);
    }

    @Test
    void testDeleteBooking() {
        int bookingId = 1;
        adminController.deleteBooking(bookingId);
        verify(adminService).deleteBooking(bookingId);
    }

    @Test
    void testCreateBooking() {
        int id = 1;
        Bookings booking = new Bookings();
        when(adminService.createBooking(eq(id), any(Bookings.class))).thenReturn(booking);
        Bookings createdBooking = adminController.createBooking(id, booking);
        assertEquals(booking, createdBooking);
        verify(adminService).createBooking(id, booking);
    }

    @Test
    void testAssignRandomWasher() {
        int bookingId = 1;
        adminController.assignRandomWasher(bookingId);
        verify(adminService).assignRandomWasher(bookingId);
    }

    @Test
    void testGetBookingWithWasher() {
        int id = 1;
        BookingResponse bookingResponse = new BookingResponse();
        when(adminService.getBookingWithWasher(id)).thenReturn(bookingResponse);
        BookingResponse retrievedResponse = adminController.getBookingWithWasher(id);
        assertEquals(bookingResponse, retrievedResponse);
        verify(adminService).getBookingWithWasher(id);
    }

    @Test
    void testGetBookingsByUserId() {
        int userId = 1;
        List<Bookings> bookings = new ArrayList<>();
        bookings.add(new Bookings());
        when(adminService.getBookingsByUserId(userId)).thenReturn(bookings);
        List<Bookings> retrievedBookings = adminController.getBookingsByUserId(userId);
        assertEquals(bookings, retrievedBookings);
        verify(adminService).getBookingsByUserId(userId);
    }

    // Add more tests for other methods in the AdminController if needed

}
