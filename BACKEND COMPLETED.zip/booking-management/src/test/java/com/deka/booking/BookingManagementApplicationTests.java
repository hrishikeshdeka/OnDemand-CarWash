package com.deka.booking;

import com.deka.booking.controllers.BookingController;
import com.deka.booking.entites.Bookings;
import com.deka.booking.entites.User;
import com.deka.booking.entites.Washer;
import com.deka.booking.service.BookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class BookingManagementApplicationTests {

    @Mock
    private BookingService bookingService;

    @InjectMocks
    private BookingController bookingController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateBooking() {
        Bookings booking = new Bookings();
        when(bookingService.createBooking(any(Bookings.class))).thenReturn(booking);
        Bookings createdBooking = bookingController.createBooking(booking);
        assertEquals(booking, createdBooking);
        verify(bookingService).createBooking(booking);
    }

    @Test
    void testGetBookingById() {
        int bookingId = 1;
        Bookings booking = new Bookings();
        when(bookingService.getBookingById(bookingId)).thenReturn(booking);
        Bookings retrievedBooking = bookingController.getBookingById(bookingId);
        assertEquals(booking, retrievedBooking);
        verify(bookingService).getBookingById(bookingId);
    }

    @Test
    void testGetAllBookings() {
        List<Bookings> bookingList = new ArrayList<>();
        bookingList.add(new Bookings());
        when(bookingService.getAllBookings()).thenReturn(bookingList);
        List<Bookings> retrievedBookings = bookingController.getAllBookings();
        assertEquals(bookingList, retrievedBookings);
        verify(bookingService).getAllBookings();
    }

    @Test
    void testUpdateBooking() {
        int bookingId = 1;
        Bookings booking = new Bookings();
        when(bookingService.updateBooking(eq(bookingId), any(Bookings.class))).thenReturn(booking);
        Bookings updatedBooking = bookingController.updateBooking(bookingId, booking);
        assertEquals(booking, updatedBooking);
        verify(bookingService).updateBooking(bookingId, booking);
    }

    @Test
    void testDeleteBooking() {
        int bookingId = 1;
        bookingController.deleteBooking(bookingId);
        verify(bookingService).deleteBooking(bookingId);
    }

    @Test
    void testGetUserByEmail() {
        String email = "test@example.com";
        Optional<User> user = Optional.of(new User());
        when(bookingService.getUserByEmail(email)).thenReturn(user);
        Optional<User> retrievedUser = bookingController.getUserByEmail(email);
        assertEquals(user, retrievedUser);
        verify(bookingService).getUserByEmail(email);
    }

    @Test
    void testGetUser() {
        int userId = 1;
        User user = new User();
        when(bookingService.getUser(userId)).thenReturn(user);
        User retrievedUser = bookingController.getUser(userId);
        assertEquals(user, retrievedUser);
        verify(bookingService).getUser(userId);
    }

    @Test
    void testGetWasherForBooking() {
        int washerId = 1;
        Washer washer = new Washer();
        when(bookingService.getWasherById(washerId)).thenReturn(washer);
        Washer retrievedWasher = bookingController.getWasherForBooking(washerId);
        assertEquals(washer, retrievedWasher);
        verify(bookingService).getWasherById(washerId);
    }

    @Test
    void testAssignRandomWasher() {
        int bookingId = 1;
        bookingController.assignRandomWasher(bookingId);
        verify(bookingService).assignRandomWasher(bookingId);
    }

    // Add more tests for other methods in the BookingController if needed

}
