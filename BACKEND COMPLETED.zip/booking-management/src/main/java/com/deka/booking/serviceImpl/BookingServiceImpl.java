package com.deka.booking.serviceImpl;

import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.stereotype.Service;

import com.deka.booking.entites.Admin;
import com.deka.booking.entites.Bookings;
import com.deka.booking.entites.TransactionDetails;
import com.deka.booking.entites.User;
import com.deka.booking.entites.Washer;
import com.deka.booking.proxy.UserClientProxy;
import com.deka.booking.proxy.WasherClientProxy;
import com.deka.booking.proxy.WashpackClientProxy;
import com.deka.booking.repositories.BookingRepo;
import com.deka.booking.service.BookingService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;

@Service
public class BookingServiceImpl implements BookingService {


	@Autowired
	private MailSender mailSender;

	private static final String KEY = "rzp_test_YB4SzxEhCpLWjS";
	private static final String KEY_SECRET = "Hv7RObUxWwvZhhm8WdaQ8oth";
	private static final String CURRENCY = "INR";

	private static final Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);

	@Autowired
	private WashpackClientProxy washpackProxy;

	@Autowired
	private UserClientProxy userProxy;

	@Autowired
	private WasherClientProxy washerProxy;

	@Autowired
	private BookingRepo bookingRepository;

//	@Override
//	public Bookings createBooking(Bookings booking) {
//		return bookingRepository.save(booking);
//	}
	@Override
	public Bookings createBooking(Bookings booking) {
	    // Save the booking
	    Bookings savedBooking = bookingRepository.save(booking);

	    // Send email notification
	    String recipientEmail = "hdks7899@gmail.com"; // Hardcoded email address
	    String subject = "Booking Confirmation";
	    String message = "Your booking has been confirmed. Thank you!";
	    
	    SimpleMailMessage email = new SimpleMailMessage();
	    email.setTo(recipientEmail);
	    email.setSubject(subject);
	    email.setText(message);

	    mailSender.send(email);

	    return savedBooking;
	}

	@Override
	public Bookings getBookingById(int id) {
		return bookingRepository.findById(id).orElse(null);
	}

	@Override
	public List<Bookings> getAllBookings() {
		return bookingRepository.findAll();
	}

	@Override
	public void saveBookingStatus(Bookings booking) {
		// Implement the logic to save the updated booking status to the database
		// For example:
		bookingRepository.save(booking);
	}

	@Override
	public Bookings updateBooking(int id, Bookings booking) {
		Bookings existingBooking = bookingRepository.findById(id).orElse(null);
		if (existingBooking != null) {
			existingBooking.setCarName(booking.getCarName());
			existingBooking.setAddress(booking.getAddress());
			existingBooking.setPackName(booking.getPackName());
			existingBooking.setDate(booking.getDate());
			existingBooking.setTime(booking.getTime());

			return bookingRepository.save(existingBooking);
		}
		return null;
	}

	@Override
	public void deleteBooking(int id) {
		bookingRepository.deleteById(id);
	}

	@Override
	public List<Admin> getByWashPackName(String washPackName) {

		return washpackProxy.getAdminByWashPackName(washPackName);
	}

	@Override
	public Optional<User> getUserByEmail(String email) {
		return userProxy.getUserByEmail(email);
	}

	@Override
	public User getUser(Integer id) {
		return userProxy.getUser(id);
	}

	// fetched userId from user-management now creating a booking with userID
	@Override
	public Bookings createBooking(Integer id, Bookings booking) {
		User user = userProxy.getUser(id);
		if (user != null) {
			// Set the userId in the booking
			booking.setId(id);
			// Perform any additional logic for booking a car wash
			// Save the booking in the booking repository
			return bookingRepository.save(booking);

		} else {
			// Handle the case where the user with the given userId is not found
			throw new IllegalArgumentException("User not found with ID: " + id);
		}

	}

	// fetching list of washers
	@Override
	public List<Washer> getAllWashers() {
		return washerProxy.getAllWashers();
	}

	// Logic Assigning Washer to the Booking
	public void assignRandomWasher(int bookingId) {
		// Retrieve the booking from the repository
		Optional<Bookings> optionalBooking = bookingRepository.findById(bookingId);
		if (optionalBooking.isEmpty()) {
			throw new RuntimeException("Booking not found");
		}

		Bookings booking = optionalBooking.get();

		// Call the washer-management microservice to get all washers
		List<Washer> washers = washerProxy.getAllWashers();

		// Randomly select a washer
		Random random = new Random();
		int randomIndex = random.nextInt(washers.size());
		Washer randomWasher = washers.get(randomIndex);

		// Assign the washer to the booking
		booking.setWasherId(randomWasher.getId());

		// Save the updated booking
		bookingRepository.save(booking);

	}

	// display washer by its id
	@Override
	public Washer getWasherById(Integer id) {
		return washerProxy.getWasherById(id);
	}

	// display Booking of user by UserId
	@Override
	public List<Bookings> getBookingsByUserId(Integer userId) {
		return bookingRepository.findByUserId(userId);
	}

	// Displaying Washpack details by packName

	@Override
	public Bookings getLastBookingByUserId(Integer userId) {
		return bookingRepository.findTopByUserIdOrderByIdDesc(userId);
	}

	// display Booking of washer by WasherId
	@Override
	public List<Bookings> getBookingsByWasherId(Integer washerId) {
		return bookingRepository.findByWasherId(washerId);
	}

	// PAYMENT SERVICES
	@Override
	public TransactionDetails createTransaction(Double amount) {
		try {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("amount", (amount * 100));
			jsonObject.put("currency", CURRENCY);

			RazorpayClient razorpayClient = new RazorpayClient(KEY, KEY_SECRET);
			Order order = razorpayClient.orders.create(jsonObject);
//			logger.info("Order Details: {}", order);

			return prepareTransactionDetails(order);
			// {"amount":100000,"amount_paid":0,"notes":[],"created_at":1686671711,
//				"amount_due":100000,"currency":"INR","receipt":null,
//				"id":"order_M1TGYf2QVnh43Y","entity":"order","offer_id":null,
//				"status":"created","attempts":0}

		} catch (Exception e) {
			logger.info("RazorPay Exception: {}", e.getMessage());
		}
		return null;

	}

	private TransactionDetails prepareTransactionDetails(Order order) {
		String orderId = order.get("id");
		String currency = order.get("currency");
		Integer amount = order.get("amount");
		String status = order.get("status");

		TransactionDetails transactionDetails = new TransactionDetails(orderId, currency, amount, status);
		return transactionDetails;
	}

}
