package com.deka.booking.entites;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Bookings {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "service_id")
	private int id;
	private String carName;
	private String address;
	private String packName;
	@Column(name = "schedule_date")
	private String date;
	@Column(name = "schedule_time")
	private String time;
	@Column(name = "washer_id")
	private Integer washerId;
	@Column(name = "user_id")
	private Integer userId;
	private String bookingStatus="NOT CONFIRMED";
	
	
	

}
