package com.deka.booking.controllers;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deka.booking.entites.Admin;
import com.deka.booking.entites.BookingDetailsResponse;
import com.deka.booking.entites.Bookings;
import com.deka.booking.entites.BookingsOfUser;
import com.deka.booking.entites.BookingsOfWasher;
import com.deka.booking.entites.Invoice;
import com.deka.booking.entites.TransactionDetails;
import com.deka.booking.entites.User;
import com.deka.booking.entites.Washer;
import com.deka.booking.service.BookingService;

@RestController
@RequestMapping("api/booking")
@CrossOrigin(origins = "http://localhost:3000")
public class BookingController {

	@Autowired
	private BookingService bookingService;

	private static final Logger logger = LoggerFactory.getLogger(BookingController.class);

	@GetMapping("/washpacks/search/{washPackName}")
	public List<Admin> getAdminByWashPackName(@PathVariable("washPackName") String washPackName) {
		return bookingService.getByWashPackName(washPackName);
	}

	@PostMapping("/submit")
	public Bookings createBooking(@RequestBody Bookings booking) {
		return bookingService.createBooking(booking);
	}
	

	@GetMapping("get/{id}")
	public Bookings getBookingById(@PathVariable int id) {
		return bookingService.getBookingById(id);
	}

	@GetMapping("get/all")
	public List<Bookings> getAllBookings() {
		return bookingService.getAllBookings();
	}

	@PutMapping("edit/{id}")
	public Bookings updateBooking(@PathVariable int id, @RequestBody Bookings booking) {
		return bookingService.updateBooking(id, booking);
	}

	@DeleteMapping("delete/{id}")
	public void deleteBooking(@PathVariable int id) {
		bookingService.deleteBooking(id);
	}

	@GetMapping("/email/{email}")
	public Optional<User> getUserByEmail(@PathVariable String email) {
		Optional<User> user = bookingService.getUserByEmail(email);
		if (user.isPresent()) {
			logger.info("Retrieved user with email {}: {}", email, user.get());
		} else {
			logger.warn("User with email {} not found", email);
		}
		return user;
	}

	@GetMapping("/user/{id}")
	public User getUser(@PathVariable Integer id) {
		return bookingService.getUser(id);
	}

	@GetMapping("/washer/{id}")
	public Washer getWasherForBooking(@PathVariable Integer id) {
		return bookingService.getWasherById(id);
	}

	@PutMapping("/{bookingId}/assign-washer")
	public String assignRandomWasher(@PathVariable int bookingId) {
		bookingService.assignRandomWasher(bookingId);
		logger.info("Assigned a random washer to booking with ID: {}", bookingId);
		return "Washer assigned successfully";
	}

	// Get Bookings List of the user by userId
	@GetMapping("/user/bookings/{userId}")
	public List<Bookings> getBookingsByUserId(@PathVariable Integer userId) {
		return bookingService.getBookingsByUserId(userId);
	}

	// Get Bookings List of the washer by washerId
	@GetMapping("/washer/bookings/{washerId}")
	public List<Bookings> getBookingsByWasherId(@PathVariable Integer washerId) {
		return bookingService.getBookingsByWasherId(washerId);
	}

	// Get bookings associated to user -Orders for users

	@GetMapping("/latest/{userId}")
	public ResponseEntity<Bookings> getLastBookingByUserId(@PathVariable Integer userId) {
		Bookings lastBooking = bookingService.getLastBookingByUserId(userId);
		if (lastBooking != null) {
			return ResponseEntity.ok(lastBooking);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	// CREATE BOOKING AND ASSIGN-WASHER.

	@PostMapping("/create-booking/assign-washer")
	public Bookings createBookingAndAssignWasher(@RequestBody Bookings booking) {
		Bookings createdBooking = bookingService.createBooking(booking);
		int bookingId = createdBooking.getId();
		bookingService.assignRandomWasher(bookingId);
		logger.info("Assigned a random washer to booking with ID: {}", bookingId);
		return createdBooking;
	}

	// SET BoOKING STATUS to CONFIRMED.
	@PutMapping("/booking-status/{id}")
	public void confirmBooking(@PathVariable int id) {
	    // Fetch the booking by id from the database
	    Bookings booking = bookingService.getBookingById(id);
	    
	    // Update the booking status to "CONFIRMED"
	    booking.setBookingStatus("CONFIRMED");
	    
	    // Save the updated booking to the database
	    bookingService.saveBookingStatus(booking);
	}


	// GET BOOKINGS OF THE USER.

	@GetMapping("/bookings-user/{userId}")
	public BookingsOfUser getUserAndBookings(@PathVariable Integer userId) {
		User user = bookingService.getUser(userId);
		List<Bookings> bookings = bookingService.getBookingsByUserId(userId);
		BookingsOfUser response = new BookingsOfUser(user, bookings);

		logger.info("Retrieved user and bookings for user with id {}: {}", userId, response);

		return response;
	}

	// GET BOOKINGS ASSOCIATED TO THE WASHER -- Work assigned to washers

	@GetMapping("/bookings-washer/{washerId}")
	public BookingsOfWasher getWasherAndBookings(@PathVariable Integer washerId) {
		Washer washer = bookingService.getWasherById(washerId);
		List<Bookings> bookings = bookingService.getBookingsByWasherId(washerId);
		BookingsOfWasher response = new BookingsOfWasher(washer, bookings);

		logger.info("Retrieved user and bookings for user with id {}: {}", washerId, response);

		return response;
	}

	// GET ALL DETAILS ASSOCIATED TO THE BOOKING DETAILS .
	@GetMapping("/booking-details/{id}")
	public BookingDetailsResponse getBookingDetails(@PathVariable int id) {
		Bookings booking = bookingService.getBookingById(id);
		Washer washer = bookingService.getWasherById(booking.getWasherId());
		User user = bookingService.getUser(booking.getUserId());

		BookingDetailsResponse response = new BookingDetailsResponse(booking, washer, user);
		logger.info("Retrieved booking details for booking with id {}: {}", id, response);

		return response;
	}

	// Invoice
	@GetMapping("/invoice/{id}")
	public Invoice getCombinedDetailsById(@PathVariable int id) {
		Bookings booking = bookingService.getBookingById(id);
		User user = bookingService.getUser(booking.getUserId());
		List<Admin> washpacks = bookingService.getByWashPackName(booking.getPackName());
		Washer washer = bookingService.getWasherById(booking.getWasherId());

		Invoice response = new Invoice(booking, washpacks, washer, user);
		logger.info("Retrieved combined details for booking with id {}: {}", id, response);

		return response;
	}

	// PAYEMENT
	@GetMapping("/createTransaction/{amount}")
	public TransactionDetails createTransaction(@PathVariable Double amount) {
		return bookingService.createTransaction(amount);
	}

}
