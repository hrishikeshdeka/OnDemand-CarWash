package com.deka.booking.service;

import java.util.List;
import java.util.Optional;

import com.deka.booking.entites.Admin;
import com.deka.booking.entites.Bookings;
import com.deka.booking.entites.TransactionDetails;
import com.deka.booking.entites.User;
import com.deka.booking.entites.Washer;

public interface BookingService {

	Bookings createBooking(Bookings booking);

	Bookings getBookingById(int id);

	List<Bookings> getAllBookings();

	Bookings updateBooking(int id, Bookings booking);

	void deleteBooking(int id);
	
	void saveBookingStatus(Bookings booking);

//getting WASHPACK DETAILS FROM ADMIN
	List<Admin> getByWashPackName(String washPackName);

//get user details from the email id.
	Optional<User> getUserByEmail(String email);

	// get user details by userId.
	User getUser(Integer id);

	// fetched userId from user-management now creating a booking with userID
	Bookings createBooking(Integer id, Bookings booking);

	// fetching the list of washers->
	List<Washer> getAllWashers();

//fetch the list of bookings by userId.
	List<Bookings> getBookingsByUserId(Integer userId);

	// fetch the list of bookings by washerId
	List<Bookings> getBookingsByWasherId(Integer washerId);

	// assignRandom washer
	void assignRandomWasher(int bookingId);

	// get washer details by id.
	Washer getWasherById(Integer id);

	Bookings getLastBookingByUserId(Integer userId);

	// PAYMENT SERVICES
	TransactionDetails createTransaction(Double amount);
	
	//mailing
}
