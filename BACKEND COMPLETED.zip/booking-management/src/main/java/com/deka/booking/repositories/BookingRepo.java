package com.deka.booking.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deka.booking.entites.Bookings;

public interface BookingRepo extends JpaRepository<Bookings, Integer> {

	List<Bookings> findByUserId(Integer userId);

	List<Bookings> findByWasherId(Integer washerId);

	Bookings findTopByUserIdOrderByIdDesc(Integer userId);

}
