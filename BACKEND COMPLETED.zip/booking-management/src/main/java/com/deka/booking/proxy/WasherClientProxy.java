package com.deka.booking.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deka.booking.entites.Washer;

@FeignClient(name = "Washer-Management")
public interface WasherClientProxy {

	@GetMapping("api/washer/all")
	List<Washer> getAllWashers();

	@GetMapping("/api/washer/{id}")
	Washer getWasherById(@PathVariable("id") Integer id);
}
