package com.deka.booking.entites;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter 
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data 
public class BookingsOfUser {
	
	 private User user;
	 private List<Bookings> bookings;


}
