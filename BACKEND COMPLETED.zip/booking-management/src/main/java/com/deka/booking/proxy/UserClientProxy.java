package com.deka.booking.proxy;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deka.booking.entites.User;

@FeignClient(name = "User-Management")
public interface UserClientProxy {

	@GetMapping("api/user/email/{email}")
	Optional<User> getUserByEmail(@PathVariable("email") String email);

	@GetMapping("/api/user/{id}")
	User getUser(@PathVariable("id") Integer id);
}
