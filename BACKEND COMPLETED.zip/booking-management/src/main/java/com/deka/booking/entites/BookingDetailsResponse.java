package com.deka.booking.entites;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BookingDetailsResponse {
	
	private Bookings booking;
	private Washer washer;
	private User user;

}
