package com.deka.booking.entites;


//@RequiredArgsConstructor
public enum Role {

  USER,
  ADMIN
}
