package com.deka.UserControllerTest;

import com.security.controller.UserController;
import com.security.service.UserService;
import com.security.user.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class UserControllerTests {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateUser() {
        User user = new User();
        when(userService.create(any(User.class))).thenReturn(user);
        User createdUser = userController.createUser(user);
        assertEquals(user, createdUser);
        verify(userService).create(user);
    }

    @Test
    void testGetAllUsers() {
        List<User> userList = new ArrayList<>();
        userList.add(new User());
        when(userService.getAll()).thenReturn(userList);
        List<User> retrievedUsers = userController.getAllUsers();
        assertEquals(userList, retrievedUsers);
        verify(userService).getAll();
    }

    @Test
    void testGetUser() {
        int userId = 1;
        User user = new User();
        when(userService.getSingle(userId)).thenReturn(user);
        User retrievedUser = userController.getUser(userId);
        assertEquals(user, retrievedUser);
        verify(userService).getSingle(userId);
    }

    @Test
    void testDeleteUser() {
        int userId = 1;
        userController.deleteUser(userId);
        verify(userService).delete(userId);
    }

    @Test
    void testUpdateUser() {
        int userId = 1;
        User user = new User();
        when(userService.update(any(User.class), eq(userId))).thenReturn(user);
        User updatedUser = userController.updateUser(userId, user);
        assertEquals(user, updatedUser);
        verify(userService).update(user, userId);
    }

    @Test
    void testGetUserByEmail() {
        String email = "test@example.com";
        Optional<User> user = Optional.of(new User());
        when(userService.findByEmail(email)).thenReturn(user);
        Optional<User> retrievedUser = userController.getUserByEmail(email);
        assertEquals(user, retrievedUser);
        verify(userService).findByEmail(email);
    }
}
