package com.security.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.security.service.UserService;
import com.security.user.User;

@RestController
@RequestMapping("api/user")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
	
	// Logger instance for logging
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);


	@Autowired
	private UserService userService;

	@PostMapping("/create")
	public User createUser(@RequestBody User user) {
		User createdUser = userService.create(user);
		logger.info("User created: {}", createdUser);
		return createdUser;
	}

	@GetMapping("/all")
	public List<User> getAllUsers() {
		List<User> users = userService.getAll();
		logger.info("Retrieved all users: {}", users);
		return users;
	}

	// @PreAuthorize("hasRole('USER')")
	@GetMapping("/{id}")
	public User getUser(@PathVariable Integer id) {
		User user = userService.getSingle(id);
		if (user != null) {
			logger.info("Retrieved user with ID {}: {}", id, user);
		} else {
			logger.warn("User with ID {} not found", id);
		}
		return user;
	}

	@DeleteMapping("delete/{id}")
	public void deleteUser(@PathVariable Integer id) {
		userService.delete(id);
		logger.info("Deleted user with ID: {}", id);
	}

    @PutMapping("edit/{id}")
    public User updateUser(@PathVariable Integer id, @RequestBody User user) {
        return userService.update(user, id);
    }

	@GetMapping("/email/{email}")
	public Optional<User> getUserByEmail(@PathVariable String email) {
		Optional<User> user = userService.findByEmail(email);
		if (user.isPresent()) {
			logger.info("Retrieved user with email {}: {}", email, user.get());
		} else {
			logger.warn("User with email {} not found", email);
		}
		return user;
	}
}
