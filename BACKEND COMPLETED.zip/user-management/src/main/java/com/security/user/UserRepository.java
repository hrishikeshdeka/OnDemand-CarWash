package com.security.user;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface UserRepository extends JpaRepository<User, Integer> {

	Optional<User> findByEmail(String email);

	
	@Modifying
	@Transactional
	@Query("UPDATE User u SET u.firstname = :firstname, u.lastname = :lastname, u.email = :email, u.password = :password WHERE u.id = :id")
	void updateUser(@Param("id") Integer id, @Param("firstname") String firstname, @Param("lastname") String lastname,
			@Param("email") String email, @Param("password") String password);

}
