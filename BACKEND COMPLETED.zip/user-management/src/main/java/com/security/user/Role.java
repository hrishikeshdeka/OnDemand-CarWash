package com.security.user;


//@RequiredArgsConstructor
public enum Role {

  USER,
  ADMIN
}
