package com.security.auth;

import java.util.Optional;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.security.config.JwtService;
import com.security.user.Role;
import com.security.user.User;
import com.security.user.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthenticationService {

	private final UserRepository repository;
	private final PasswordEncoder passwordEncoder;
	private final JwtService jwtService;
	private final AuthenticationManager authenticationManager;

//register
	public AuthenticationResponse register(RegisterRequest request) {
		var user = User.builder().firstname(request.getFirstname()).lastname(request.getLastname())
				.email(request.getEmail()).phone(request.getPhone())
				.password(passwordEncoder.encode(request.getPassword())).role(Role.USER).build();
		repository.save(user);
		var jwtToken = jwtService.generateToken(user);

		return AuthenticationResponse.builder().token(jwtToken)

				.build();
	}

//
	public AuthenticationResponse registerAdmin(RegisterRequest request) {
		var user = User.builder().firstname(request.getFirstname()).lastname(request.getLastname())
				.email(request.getEmail()).phone(request.getPhone())
				.password(passwordEncoder.encode(request.getPassword())).role(Role.ADMIN).build();
		repository.save(user);
		var jwtToken = jwtService.generateToken(user);

		return AuthenticationResponse.builder().token(jwtToken).build();
	}

	// login for USER

	public AuthenticationResponse authenticate(AuthenticationRequest request) {
	    authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
	    var user = repository.findByEmail(request.getEmail()).orElseThrow();

	    if (user.getRole() != Role.USER) {
	        throw new RuntimeException("Invalid role. Only users can authenticate.");
	    }

	    var jwtToken = jwtService.generateToken(user);

	    return AuthenticationResponse.builder().token(jwtToken).build();
	}
	
	// login for ADMIN
	public AuthenticationResponse authenticateAdmin(AuthenticationRequest request) {
	    authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
	    var user = repository.findByEmail(request.getEmail()).orElseThrow();

	    if (user.getRole() != Role.ADMIN) {
	        throw new RuntimeException("Invalid role. Only admins can authenticate.");
	    }

	    var jwtToken = jwtService.generateToken(user);

	    return AuthenticationResponse.builder().token(jwtToken).build();
	}

//Putmapping

	public void updateUserById(Integer id, UpdatedUserRequest request) {
		Optional<User> optionalUser = repository.findById(id);

		if (optionalUser.isPresent()) {
			User user = optionalUser.get();

			user.setFirstname(request.getFirstname());
			user.setLastname(request.getLastname());
			user.setEmail(request.getEmail());
			user.setPhone(request.getPhone());

			// If you want to update the password, you can do so like this:
			if (request.getPassword() != null) {
				String encodedPassword = passwordEncoder.encode(request.getPassword());
				user.setPassword(encodedPassword);
			}

			repository.save(user);
		} else {

		}
	}
}
