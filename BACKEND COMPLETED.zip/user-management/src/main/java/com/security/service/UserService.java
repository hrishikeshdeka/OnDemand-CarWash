package com.security.service;

import java.util.List;
import java.util.Optional;

import com.security.user.User;

public interface UserService {

	User create(User user);

	List<User> getAll();

	User getSingle(Integer id);

	void delete(Integer id);

	Optional<User> findByEmail(String email);

	User update(User user, Integer id);
}
