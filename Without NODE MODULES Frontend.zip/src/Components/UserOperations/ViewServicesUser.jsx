import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ANavbar from '../ANavbar';
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/ViewServicesUser.css';
import car1 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/painting-machine-parts-white-paint-angle-grinder_1157-46147.avif';
import car2 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/car-wash-detailing-station_1303-22307.avif';
import car3 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/man-washing-his-car-garage_1157-26046.avif';
import car4 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/crop-man-pouring-hot-water-into-cup_23-2147775863.avif';
import car5 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/close-up-person-cleaning-car-interior_23-2148194081.avif';
import Footer from '../Footer';
const ViewServicesUser = () => {
  const [washPacks, setWashPacks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWashPacks = async () => {
      try {
        const response = await axios.get('http://localhost:9003/api/admin/washpacks/all');
        const washPacksData = response.data;
        setWashPacks(washPacksData);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching wash packs:', error);
        setLoading(false);
      }
    };

    fetchWashPacks();
  }, []);

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div className='whitesmoke-bg'>
      <ANavbar />
      <div className="wash-packs-grid">
        {washPacks.map((washPack, index) => (
          <div key={index} className="wash-pack">
            <div className="image-container smaller-grid">
              {index === 0 && <img src={car2} alt={washPack.washPackName} />}
              {index === 1 && <img src={car1} alt={washPack.washPackName} />}
              {index === 2 && <img src={car3} alt={washPack.washPackName} />}
              {index === 3 && <img src={car4} alt={washPack.washPackName} />}
              {index === 4 && <img src={car5} alt={washPack.washPackName} />}
              {index === 5 && <img src={car1} alt={washPack.washPackName} />}
              {index === 6 && <img src={car2} alt={washPack.washPackName} />}
              {index === 7 && <img src={car3} alt={washPack.washPackName} />}
              {index === 8 && <img src={car4} alt={washPack.washPackName} />}
            </div>
            <div className="content">
              <h3>{washPack.washPackName}</h3>
              <p>{washPack.washPackPrice}</p>
              <p>{washPack.washPackDesc}</p>
            </div>
          </div>
        ))}
      </div>
      <Footer/>
    </div>
  );
};


export default ViewServicesUser;
