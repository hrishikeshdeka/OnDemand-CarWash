import { useEffect } from "react";
import BookingService from "../Service/BookingService";
import { toast } from "react-toastify";
import { useParams, useNavigate } from "react-router-dom";

export default function PaymentUser() {
  const { washpackPrice } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const loadRazorpayScript = () => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.async = true;
      document.body.appendChild(script);
    };

    const paymentStart = () => {
      console.log("Payment Started");
      let amount = washpackPrice;
      console.log(amount);
      BookingService.createTransaction(amount)
        .then((response) => {
          if (response.data.status === "created") {
            const options = {
              key: "rzp_test_YB4SzxEhCpLWjS",
              amount: response.data.amount,
              currency: "INR",
              name: "Wash Wheels Payment Gateway",
              description: "Bill",
              image:
                "https://pbs.twimg.com/profile_images/942832058551844864/vSEWCwfT_400x400.jpg",
              order_id: response.data.orderId,
              handler: function (response) {
                console.log(response.razorpay_payment_id);
                console.log(response.razorpay_order_id);
                console.log(response.razorpay_signature);
                toast.success("Payment Successful");
                // Redirect to invoice details page
                window.location.href = "http://localhost:3000/login/user"; // Replace with the actual URL of the invoice details page
              },
              prefill: {
                name: "",
                email: "",
                contact: "",
              },
              notes: {
                address: "Happy Customer",
              },
            };

            const rzp = new window.Razorpay(options);

            rzp.on("payment.failed", function (response) {
              console.log(response.error.code);
              console.log(response.error.description);
              console.log(response.error.source);
              console.log(response.error.step);
              console.log(response.error.reason);
              console.log(response.error.metadata.order_id);
              console.log(response.error.metadata.payment_id);
              alert("Oops Payment failed !!");
            });
            rzp.open();
          }
        })
        .catch((error) => {
          toast.error("Something went wrong on the server end");
          console.log(error);
        });
    };

    loadRazorpayScript();
    paymentStart();
  }, [washpackPrice, navigate]);

  return null; // Render nothing or a loading indicator since this component is used for side effects only
}
