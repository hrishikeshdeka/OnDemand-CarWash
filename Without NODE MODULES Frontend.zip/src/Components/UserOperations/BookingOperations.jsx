import React, { useState } from 'react';
import axios from 'axios';
import ANavbar from '../ANavbar';
import GetEmailById from './GetEmailById';
import GetLatestBookingUser from './GetLatestBookingUser';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import TimePicker from 'react-time-picker';
import 'react-time-picker/dist/TimePicker.css';
import carImg2 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/appointment-booking-with-calendar-concept_23-2148556783.avif';
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/BookingOperations.css';
import Footer from '../Footer';

const BookingOperations = () => {
  const [carName, setCarName] = useState('');
  const [address, setAddress] = useState('');
  const [packName, setPackName] = useState('');
  const [date, setDate] = useState(new Date());
  const [time, setTime] = useState('');
  const [userId, setUserId] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:9002/api/booking/create-booking/assign-washer', {
        carName,
        address,
        packName,
        date,
        time,
        userId,
      });

      const createdBooking = response.data;
      console.log('Created booking:', createdBooking);

      window.alert('You\'ve created a Booking!');
    } catch (error) {
      console.error('Error creating booking:', error);
      window.alert('Error creating booking:', error);
    }
  };

  return (
    <div>
      <ANavbar />
      <div className="container booking-container">
        <div className="row">
          <div className="col-lg-6">
            <div className="email-container">
              <GetEmailById />
            </div>
            <h2 style={{ fontFamily: "Pacifico" }}>Create a booking 👇🏼 :</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="userId" className="form-label">User ID:</label>
                <input
                  type="text"
                  id="userId"
                  value={userId}
                  className="form-control"
                  placeholder='Enter your unique User ID'
                  onChange={(e) => setUserId(e.target.value)}
                  required
                />
              </div>

              <div className="mb-3">
                <label htmlFor="carName" className="form-label">Vehicle Name:</label>
                <input
                  type="text"
                  id="carName"
                  value={carName}
                  className="form-control"
                  placeholder='Enter Vehicle Name'
                  onChange={(e) => setCarName(e.target.value)}
                  required
                />
              </div>

              <div className="mb-3">
                <label htmlFor="address" className="form-label">Address:</label>
                <input
                  type="text"
                  id="address"
                  className="form-control"
                  placeholder='Enter your Address'
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  required
                />
              </div>

              <div className="mb-3">
                <label htmlFor="packName" className="form-label">Services:</label>
                <select
                  id="packName"
                  value={packName}
                  className="form-control"
                  onChange={(e) => setPackName(e.target.value)}
                  required
                >
                  <option value="">Select a Service</option>
                  <option value="Silver Wash">Silver Wash</option>
                  <option value="Gold Wash">Gold Wash</option>
                  <option value="Platinum Wash">Platinum Wash</option>
                  <option value="Basic Internal Cleaning">Basic Internal Cleaning</option>
                  <option value="Intense Internal Cleaning">Intense Internal Cleaning</option>
                  <option value="Wax Rubbing And Buffing">Wax Rubbing And Buffing</option>
                  <option value="Teflon Coating">Teflon Coating</option>
                  <option value="WindSheild Treatment">WindSheild Treatment</option>
                  <option value="Leather Conditioning">Leather Conditioning</option>
                </select>
              </div>

              <div className="mb-3">
                <label htmlFor="date" className="form-label">Select Date:</label>
                <DatePicker
                  id="date"
                  selected={date}
                  onChange={(date) => setDate(date)}
                  minDate={new Date()}
                  dateFormat="dd/MM/yy"
                  className="form-control"
                  required
                />
              </div>

              <div className="mb-3">
                <label htmlFor="time" className="form-label">Time:</label>
                <TimePicker
                  id="time"
                  value={time}
                  onChange={(time) => setTime(time)}
                  format="hh:mm a"
                  className="form-control"
                  required
                />
              </div>

              <button type="submit" className="btn btn-primary">Create Booking</button>
            </form>

            <div>
    
                <GetLatestBookingUser />
           
              
            </div>
            <h1 style={{ color: "white" }}>.</h1>
          </div>
          <div className="col-lg-6"><img
    src={carImg2}
    alt="Car"
    className="img-fluid"
    style={{ width: '100%', height: 'auto' }}
  />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default BookingOperations;
