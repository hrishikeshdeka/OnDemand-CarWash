import React, { useState } from 'react';
import axios from 'axios';
import { Modal, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
const GetLatestBookingUser = () => {
  const [userId, setUserId] = useState('');
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await axios.get(`http://localhost:9002/api/booking/latest/${userId}`);
      if (response.status === 200) {
        setBooking(response.data);
        setShowModal(true);
      } else {
        setBooking(null);
        setShowModal(false);
      }
    } catch (error) {
      console.error('Error fetching last booking:', error);
      setBooking(null);
      setShowModal(false);
    } finally {
      setLoading(false);
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const formatDate = (date) => {
    const options = {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
    };
    return new Date(date).toLocaleDateString(undefined, options);
  };

  const formatTime = (time) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours, 10);
    const isPM = hour >= 12;
    const formattedHour = hour % 12 || 12;
    const formattedTime = `${formattedHour}:${minutes.padStart(2, '0')} ${isPM ? 'PM' : 'AM'}`;
    return formattedTime;
  };

  return (
    <div>
      <form onSubmit={handleSubmit} className="container">
        <div className="input-button">
          <input
            type="text"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            placeholder="Enter ID to get booking details"
            className="email-input"
            style={{ borderRadius: '10px', width: '270px', height: '50px' }}
          />
          <button type="submit" className="submit-button" style={{ borderRadius: '10px', width: '50px', height: '50px' }}>
            <h3>☞</h3>
          </button>
        </div>
      </form>

      {loading && <p>Loading...</p>}

      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Last Booking</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {booking && (
            <div>
              <p>Booking ID: {booking.id}</p>
              <p>Car Name: {booking.carName}</p>
              <p>Address: {booking.address}</p>
              <p>Package Name: {booking.packName}</p>
              <p>Date: {formatDate(booking.date)}</p>
              <p>Time: {formatTime(booking.time)}</p>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
        <Link to="/login/user/invoice-details">
        <Button variant="secondary" onClick={handleCloseModal}>
            Proceed To Payment Page 
          </Button>
              </Link>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default GetLatestBookingUser;
