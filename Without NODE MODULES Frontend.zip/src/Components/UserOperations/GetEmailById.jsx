import React, { useState, useEffect } from "react";
import axios from "axios";
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/GetEmailById.css';
const GetEmailById = () => {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchUserByEmail = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `http://localhost:8000/api/user/email/${email}`
      );
      const data = response.data;
      setUser(data);
      if (data) {
        console.log("Retrieved user:", data);
      } else {
        console.log("User not found");
      }
    } catch (error) {
      console.error("Error fetching user:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserByEmail();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchUserByEmail();
  };


  return (

    <div>
      <form onSubmit={handleSubmit} className="container">
        <div className="input-button">
          <input
            type="text"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter email to fetch your User ID"
            className="email-input"
            style={{ borderRadius: '10px', width: '270px', height: '50px' }}
          />
          <button type="submit" disabled={loading} className="submit-button" style={{ borderRadius: '10px', width: '50px', height: '50px' }}>
            <h3>☞</h3>
          </button>
        </div>
      </form>
      {loading && <p>Loading...</p>}
      {user && (
        <div className="card">
          <div className="card-body">
            <p className="card-text">Unique Id: {user.id}</p>
            {/* <p className="card-text">Name: {user.firstname} {user.lastname}</p>
            <p className="card-text">Email: {user.email}</p>
            <p className="card-text">Phone: {user.phone}</p> 
            <p className="card-text">Role: {user.role}</p> */}
           
          </div>
        </div>
      )}
    </div>
  );
};

export default GetEmailById;
