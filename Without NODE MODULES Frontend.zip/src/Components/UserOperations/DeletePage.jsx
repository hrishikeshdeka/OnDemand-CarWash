import React from 'react'
import del from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/deletePage.jpeg';
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/DeletePage.css';
function DeletePage() {
  return (
    <div className='delete-container'><img src={del} alt='delete'></img></div>
  )
}

export default DeletePage