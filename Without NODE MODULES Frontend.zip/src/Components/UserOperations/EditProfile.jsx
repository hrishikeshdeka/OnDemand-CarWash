import React, { useState } from "react";
import axios from "axios";
import ANavbar from "../ANavbar";
import GetEmailById from "./GetEmailById";
import Footer from "../Footer";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import edit from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/5250480.jpg';
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/EditProfile.css';

const EditProfile = () => {
  const [id, setId] = useState("");
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const MySwal = withReactContent(Swal);

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await axios.put(`http://localhost:9000/api/edit/${id}`, {
        firstname,
        lastname,
        email,
        phone,
        password,
      });

      const updatedUser = response.data;
      console.log("Updated user:", updatedUser);

      MySwal.fire({
        icon: "success",
        title: "Success!",
        text: "You have successfully edited your details.",
      }).then(() => {
        navigate("/login/user");
      });
    } catch (error) {
      console.error("Error updating user:", error);

      MySwal.fire({
        icon: "error",
        title: "Error!",
        text: "Failed to update user details. Please try again.",
      });
    }
  };

  const handleDeleteProfile = async () => {
    try {
      await axios.delete(`http://localhost:9000/api/user/delete/${id}`);
      MySwal.fire({
        icon: "success",
        title: "Success!",
        text: "User profile deleted successfully.",
      }).then(() => {
        navigate("/login/user");
      });
    } catch (error) {
      console.error("Error deleting user profile:", error);

      MySwal.fire({
        icon: "error",
        title: "Error!",
        text: "Failed to delete user profile. Please try again.",
      });
    }
  };

  return (
    <div>
      <ANavbar />
      <div className="container">
        <div className="row justify-content-left">
          <div className="col-lg-6">
            <img src={edit} alt="Image1" className="img-fluid" />
          </div>
          <div className="col-lg-6">
            <p></p>
            <p></p>
            <p></p>
            <p></p>
            <GetEmailById />
            <h2 style={{ fontFamily: "Pacifico" }}>Edit your user details 👇🏼 :</h2>
            <form onSubmit={handleFormSubmit}>
              <div className="form-group">
                <label htmlFor="id">ID:</label>
                <input
                  type="text"
                  id="id"
                  value={id}
                  onChange={(e) => setId(e.target.value)}
                  required
                  className="form-control rounded"
                />
              </div>

              <div className="form-group">
                <label htmlFor="firstname">First Name:</label>
                <input
                  type="text"
                  id="firstname"
                  value={firstname}
                  onChange={(e) => setFirstname(e.target.value)}
                  required
                  className="form-control rounded"
                />
              </div>
              <div className="form-group">
                <label htmlFor="lastname">Last Name:</label>
                <input
                  type="text"
                  id="lastname"
                  value={lastname}
                  onChange={(e) => setLastname(e.target.value)}
                  required
                  className="form-control rounded"
                />
              </div>

              <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
                  className="form-control rounded"
                />
              </div>

              <div className="form-group">
                <label htmlFor="phone">Phone Number:</label>
                <input
                  type="phone"
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  pattern="[0-9]{10}"
                  className="form-control rounded"
                />
              </div>

              <div className="form-group">
                <label htmlFor="password">Password:</label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength="1"
                  className="form-control rounded"
                />
                <small className="text-danger">
                  Password must be at least 8 characters long.
                </small>
              </div>

              <button type="submit" className="btn btn-primary">
                Update Your Profile
              </button>
              <button onClick={handleDeleteProfile} className="btn btn-danger mt-3">
              Delete Profile
            </button>
            </form>
          
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default EditProfile;
