import React, { useState } from "react";
import axios from "axios";

const ConfirmStatus = ({ bookingId }) => {
  const [error, setError] = useState("");

  const handleConfirmBooking = async () => {
    try {
      await axios.put(
        `http://localhost:9002/api/booking/booking-status/${bookingId}`
      );
      // Booking confirmed successfully
      // Perform any necessary actions or display success message
    } catch (error) {
      console.error("Error confirming booking:", error);
      setError("Failed to confirm booking");
    }
  };

  return (
    <div>
      <button className="navbar-register" style={{
                              fontSize: "17px",
                              fontWeight: "bold",
                              borderRadius: "20px",
                            }}
                            onClick={handleConfirmBooking}>Confirm Booking</button>
      {error && <p>{error}</p>}
    </div>
  );
};

export default ConfirmStatus;
