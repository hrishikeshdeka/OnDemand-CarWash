import React, { useState } from "react";
import axios from "axios";
import ANavbar from "../ANavbar";
import GetEmailById from "./GetEmailById";
import pic1 from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/appointment-booking-with-smartphone_23-2148563698.avif";
import Footer from "../Footer";

const UserOrderHistory = () => {
  const [userId, setUserId] = useState("");
  const [invoiceData, setInvoiceData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedBooking, setSelectedBooking] = useState(null);

  const fetchInvoiceData = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await axios.get(
        `http://localhost:9002/api/booking/bookings-user/${userId}`
      );
      setInvoiceData(response.data);
      console.log("Data fetched.");
    } catch (error) {
      setError("Error fetching invoice data.");
    }

    setIsLoading(false);
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    fetchInvoiceData();
  };

  const handleBookingSelect = (bookingId) => {
    if (bookingId === selectedBooking) {
      setSelectedBooking(null); // Deselect the booking if already selected
    } else {
      setSelectedBooking(bookingId); // Select the booking
    }
  };

  return (
    <div>
      <ANavbar />
      <div className="container">
        <div className="row">
          <div className="col-lg-6">
            <div>
              <h1 style={{ color: "white" }}>.</h1>
            </div>
            <div>
              <h1 style={{ color: "white" }}>.</h1>
            </div>
            <div>
              <GetEmailById />
            </div>
            <h2 style={{ fontFamily: "Pacifico" }}>Invoice User 👇🏼:</h2>
            <form onSubmit={handleFormSubmit}>
              <div className="form-group">
                <label htmlFor="userId">User ID:</label>
                <input
                  type="text"
                  id="userId"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  required
                  className="form-control"
                />
              </div>
              <button type="submit" className="btn btn-primary">
                Fetch Invoice Data
              </button>
            </form>

            {isLoading && <p>Loading...</p>}
            {error && <p>{error}</p>}
            {invoiceData && (
              <div>
                <h4>User Details:</h4>
                <p>User ID: {invoiceData.user.id}</p>
                <p>
                  Name:{" "}
                  {`${invoiceData.user.firstname} ${invoiceData.user.lastname}`}
                </p>
                <p>Email: {invoiceData.user.email}</p>
                <p>Phone: {invoiceData.user.phone}</p>

                <h4>Bookings:</h4>
                {invoiceData.bookings.map((booking) => (
                  <div key={booking.id}>
                    <button
                      type="button"
                      className="btn btn-link"
                      data-bs-toggle="modal"
                      data-bs-target={`#bookingModal-${booking.id}`}
                    >
                      Booking ID: {booking.id}
                    </button>
                    <div
                      className="modal fade"
                      id={`bookingModal-${booking.id}`}
                      tabIndex="-1"
                      aria-labelledby={`bookingModalLabel-${booking.id}`}
                      aria-hidden="true"
                    >
                      <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                          <div className="modal-header">
                            <h5
                              className="modal-title"
                              id={`bookingModalLabel-${booking.id}`}
                            >
                              Booking Details
                            </h5>
                            <button
                              type="button"
                              className="btn-close"
                              data-bs-dismiss="modal"
                              aria-label="Close"
                              onClick={() => handleBookingSelect(null)}
                            ></button>
                          </div>
                          <div className="modal-body">
                            <p>Car Name: {booking.carName}</p>
                            <p>Address: {booking.address}</p>
                            <p>Package Name: {booking.packName}</p>
                            <p>Date: {booking.date}</p>
                            <p>Time: {booking.time}</p>
                            <p>User: {booking.userId}</p>
                            <p>Booking Status: {booking.bookingStatus}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="col-lg-6">
            <img
              src={pic1}
              alt="Car"
              className="img-fluid"
              style={{ width: "100%" }}
            />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default UserOrderHistory;
