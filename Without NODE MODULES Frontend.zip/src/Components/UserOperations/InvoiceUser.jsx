import React, { useState } from "react";
import axios from "axios";
import ANavbar from "../ANavbar";
import carImg2 from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/invoice-concept-illustration_114360-2485.avif";
import "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/InvoiceUser.css";
import { Link } from "react-router-dom";
import Footer from "../Footer";
import { Button } from "react-bootstrap";
const InvoiceUser = () => {
  const [id, setId] = useState("");
  const [invoice, setInvoice] = useState(null);
  const [confirmingBooking, setConfirmingBooking] = useState(false);

  const handleFetchInvoice = async () => {
    try {
      const response = await axios.get(
        `http://localhost:9002/api/booking/invoice/${id}`
      );
      const invoiceData = response.data;
      setInvoice(invoiceData);
    } catch (error) {
      console.error("Error fetching invoice:", error);
    }
  };

  const handleConfirmBooking = async () => {
    try {
      setConfirmingBooking(true);
      await axios.put(`http://localhost:9002/api/booking/booking-status/${id}`);
      // Booking confirmed successfully
      // Perform any necessary actions or display success message
    } catch (error) {
      console.error("Error confirming booking:", error);
    } finally {
      setConfirmingBooking(false);
    }
  };

  const renderButtonContent = () => {
    if (confirmingBooking) {
      return "Confirming...";
    } else if (invoice) {
      return "Checkout and Confirm";
    } else {
      return "Get Invoice Details";
    }
  };

  return (
    <div>
      <ANavbar />
      <div className="container">
        <div className="row">
          <div className="col-lg-6">
            <h1 style={{ color: "white" }}>.</h1>
            <h2>Invoice Details:</h2>
            <label htmlFor="id">Booking ID:</label>
            <input
              type="text"
              id="id"
              className="form-control"
              placeholder="Enter your unique booking ID"
              value={id}
              onChange={(e) => setId(e.target.value)}
              required
            />

            <Button variant="dark" onClick={handleFetchInvoice}>
              Proceed To Payment
            </Button>
            {invoice && (
              <div className="card">
                <div className="card-body">
                  <div className="card-text">
                    <div>
                      <strong>Booking ID:</strong> {invoice.booking.id}
                    </div>
                    <div>
                      <strong>Car Name:</strong> {invoice.booking.carName}
                    </div>
                    <div>
                      <strong>Address:</strong> {invoice.booking.address}
                    </div>
                    <div>
                      <strong>Package Name:</strong> {invoice.booking.packName}
                    </div>
                    <div>
                      <strong>Date:</strong> {invoice.booking.date}
                    </div>
                    <div>
                      <strong>Time:</strong> {invoice.booking.time}
                    </div>
                    <div>
                      <strong>Booking Status:</strong>{" "}
                      {invoice.booking.bookingStatus}
                    </div>
                    <hr />
                    <h5>User Details</h5>
                    <div>
                      <strong>User ID:</strong> {invoice.user.id}
                    </div>
                    <div>
                      <strong>Name:</strong>{" "}
                      {`${invoice.user.firstname} ${invoice.user.lastname}`}
                    </div>
                    <div>
                      <strong>Email:</strong> {invoice.user.email}
                    </div>
                    <div>
                      <strong>Phone:</strong> {invoice.user.phone}
                    </div>
                    <hr></hr>
                    <h5>Washer Details</h5>
                    <div>
                      <strong>Washer ID:</strong> {invoice.washer.id}
                    </div>
                    <div>
                      <strong>Name:</strong>{" "}
                      {`${invoice.washer.firstname} ${invoice.washer.lastname}`}
                    </div>
                    <div>
                      <strong>Email:</strong> {invoice.washer.email}
                    </div>
                    <div>
                      <strong>Phone:</strong> {invoice.washer.phone}
                    </div>
                    <hr />
                    <h5>Service Details</h5>
                    {invoice.washpacks.map((washpack) => (
                      <div key={washpack.washpackId}>
                        <div>
                          <strong>Service Name:</strong> {washpack.washPackName}
                        </div>
                        <div>
                          <strong>Service Price(INR):</strong>{" "}
                          {washpack.washPackPrice}
                        </div>
                        <Link
                          to={`/login/user/invoice/payment/${invoice.booking.id}/${washpack.washPackPrice}`}
                        >
                          <Button
                            variant="light"
                            onClick={handleConfirmBooking}
                            disabled={confirmingBooking}
                          >
                            {renderButtonContent()}
                          </Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
            <h1 style={{ color: "white" }}>.</h1>
          </div>
          <div className="col-lg-6 d-flex justify-content-end">
            <img src={carImg2} alt="Car" className="img-fluid" />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default InvoiceUser;
