import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import ANavbar from "../ANavbar";
import Footer from "../Footer";
import UpdateUser from "./UpdateUser";
import img1 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/manage_profile.jpg';
import dustbin from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/delete.png';

const ManageProfile = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [deletionStatus, setDeletionStatus] = useState("");

  const fetchUserByEmail = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `http://localhost:8000/api/user/email/${email}`
      );
      const data = response.data;
      setUser(data);
      if (data) {
        console.log("Retrieved user:", data);
      } else {
        console.log("User not found");
      }
    } catch (error) {
      console.error("Error fetching user:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchUserByEmail();
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handleDeleteProfile = async () => {
    setLoading(true);
    try {
      await axios.delete(`http://localhost:9000/api/user/delete/${user.id}`);
      console.log("Profile deleted successfully");
      setDeletionStatus("Profile deleted successfully");
      navigate("/");
    } catch (error) {
      console.error("Error deleting profile:", error);
      setDeletionStatus("Error deleting profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <ANavbar />
      <div className="container">
        <div className="row">
          <div className="col-lg-6">
            <h2 style={{ color: "white" }}>.</h2>
            <img src={img1} alt="Image1" className="img-fluid" />
          </div>
          <div className="col-md-6">
            <div>
              <h2 style={{ color: "white" }}>.</h2>
              <h2 style={{ fontFamily: "Pacifico" }}>
                Manage your profile 👇🏼 :
              </h2>
              <h2 style={{ color: "white" }}>.</h2>
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Enter email"
                    value={email}
                    onChange={handleEmailChange}
                  />
                </div>
                <button type="submit" className="btn btn-primary">
                  Fetch User
                </button>
              </form>
              {loading && <p>Loading...</p>}
              {user && (
                <div className="card mt-3 w-75">
                  <div className="card-body">
                    <h5 className="card-title">User Details</h5>
                    <p className="card-text">Unique Id: {user.id}</p>
                    <p className="card-text">Email: {user.email}</p>
                    <p className="card-text">
                      Name: {user.firstname} {user.lastname}
                    </p>
                    <p className="card-text">Phone: {user.phone}</p>
                    <div className="d-flex">
                    <UpdateUser userId={user.id} /> <p style={{ color: "white" }}>...........................................................................</p>
                     <button className="btn" onClick={handleDeleteProfile}>
                        <img src={dustbin} alt="Delete" style={{ width: "20px", height: "20px" }} />
                      </button>

                    </div>
                  </div>
                </div>
              )}
              {deletionStatus && <p>{deletionStatus}</p>}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ManageProfile;
