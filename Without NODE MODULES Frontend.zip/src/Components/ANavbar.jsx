import React from "react";
import { Link } from "react-router-dom";
import "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/ANavbar.css";
import carWashLogo from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/Screenshot 2023-07-09 at 1.13.35 AM.png";
// import About from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/About.jsx';
// import Contact from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Contact.jsx';
// import { Login } from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Login.jsx';
// import { Register } from './Register';
import logout from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/logout.png";
const ANavbar = () => {
  return (
    <nav className="navbar">
      {/* Left side - Logo and Title */}
      <div className="navbar-left">
        <Link to="/">
          <img src={carWashLogo} alt="Logo" className="navbar-logo" />
        </Link>
        <h1 className="navbar-title">Wash Wheels</h1>
      </div>

      {/* Right side - About, Contact, and Login Button */}
      <div className="navbar-right">
        <ul className="navbar-links">
          <li>
            <Link to="/About">About</Link>
          </li>
          <li>
            <Link to="/Contact">Contact</Link>
          </li>
        </ul>
        <Link to="/">
          <button
            className="navbar-logout"
            style={{
              borderRadius: "30px",
            }}>
            <img src={logout} alt="Logout" className="logout-image" />
          </button>
        </Link>
      </div>
    </nav>
  );
};

export default ANavbar;
