import axios from 'axios';

const BASE_URL = 'http://localhost:9002/api/booking';

class BookingService {
 
  createTransaction(amount){
    return axios.get(`${BASE_URL}/createTransaction/${amount}`);
  }
}

// eslint-disable-next-line import/no-anonymous-default-export
export default new BookingService();