import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ANavbar from '../ANavbar';
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/ViewServicesUser.css';
import carImg2 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/deleteprofile.jpg';
import Footer from '../Footer';
const ViewServicesWasher = () => {
  const [washPacks, setWashPacks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWashPacks = async () => {
      try {
        const response = await axios.get('http://localhost:9003/api/admin/washpacks/all');
        const washPacksData = response.data;
        setWashPacks(washPacksData);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching wash packs:', error);
        setLoading(false);
      }
    };

    fetchWashPacks();
  }, []);

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div className='whitesmoke-bg'>
      <ANavbar />
      <div className="wash-packs-grid">
        {washPacks.map((washPack, index) => (
          <div key={index} className="wash-pack">
            <div className="image-container">
              {index === 0 && <img src={carImg2} alt={washPack.washPackName} />}
              {index === 1 && <img src={carImg2} alt={washPack.washPackName} />}
              {index === 2 && <img src={carImg2} alt={washPack.washPackName} />}
              {index === 3 && <img src={carImg2} alt={washPack.washPackName} />}
              {index === 4 && <img src={carImg2} alt={washPack.washPackName} />}
              {index === 5 && <img src={carImg2} alt={washPack.washPackName} />}
              {index === 6 && <img src={carImg2} alt={washPack.washPackName} />}
              {index === 7 && <img src={carImg2} alt={washPack.washPackName} />}
              {index === 8 && <img src={carImg2} alt={washPack.washPackName} />}
            </div>
            <div className="content">
              <h3>{washPack.washPackName}</h3>
              <p>{washPack.washPackPrice}</p>
              <p>{washPack.washPackDesc}</p>
            </div>
          </div>
        ))}
      </div>
      <Footer/>
    </div>
  );
};


export default ViewServicesWasher;
