import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ANavbar from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/ANavbar.jsx';
import GetEmailByIdWasher from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/WasherOperations/GetEmailByIdWasher.jsx';
import Footer from '../Footer';
import pic1 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/delete-concept-tiny-woman-deleting-data-smartphone-move-unnecessary-files-trash-bin_501813-581.jpg';
import 'bootstrap/dist/css/bootstrap.min.css';

const DeleteProfileWasher = () => {
  const navigate = useNavigate(); // useNavigate hook for navigation
  const [id, setId] = useState('');
  const [loading, setLoading] = useState(false);

  const deleteWasherById = async () => {
    setLoading(true);
    try {
      const response = await fetch(`http://localhost:9001/api/washer/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        console.log('Washer deleted successfully');
        navigate('/login/delete/deletepage'); // Redirect to the desired page
      } else {
        console.log('Failed to delete washer');
      }
    } catch (error) {
      console.error('Error deleting washer:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    deleteWasherById();
  };

  return (
    <div>
      <ANavbar />
      <div className="container delete-washer-container">
        <div className="row">
          <div className="col-lg-6">
          <h1 style={{ color: "white" }}>.</h1>
          
            <img src={pic1} alt="Washer" className="img-fluid" />
            <h1 style={{ color: "white" }}>.</h1>
            <h1 style={{ color: "white" }}>.</h1>
          </div>
          
          <div className="col-lg-6">
            <div>
            <h1 style={{ color: "white" }}>.</h1>

              <h1 style={{ color: "white" }}>.</h1>

            </div>
            <div className="delete-washer-right">
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <GetEmailByIdWasher />
                  <h2 style={{ fontFamily: "Pacifico" }}>Edit your unique ID 👇🏼:</h2>
                  <input
                    type="text"
                    value={id}
                    onChange={(e) => setId(e.target.value)}
                    placeholder="Enter washer ID"
                    className="form-control rounded"
                  />
                </div>
                <button type="submit" disabled={loading} className="btn btn-primary">
                  Delete Washer
                </button>
              </form>
              {loading && <p className="loading-message">Loading...</p>}
            </div>
            
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default DeleteProfileWasher;
