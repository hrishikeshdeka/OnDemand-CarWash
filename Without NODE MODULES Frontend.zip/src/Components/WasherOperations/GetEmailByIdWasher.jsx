import React, { useState, useEffect } from "react";

const GetEmailByIdWasher = () => {
  const [washer, setwasher] = useState(null);
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchwasherByEmail = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `http://localhost:9001/api/washer/email/${email}`
      );
      const data = await response.json();
      setwasher(data);
      if (data) {
        console.log("Retrieved washer:", data);
      } else {
        console.log("washer not found");
      }
    } catch (error) {
      console.error("Error fetching washer:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchwasherByEmail();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchwasherByEmail();
  };

  return (
    <div>
      <form onSubmit={handleSubmit} className="container">
      <div className="input-button">
        <input
          type="text"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email address."
          className="email-input"
          style={{ borderRadius: '10px', width: '200px', height: '50px' }}
        />
        <button type="submit" disabled={loading}className="submit-button" style={{ borderRadius: '10px', width: '50px', height: '50px' }}>
        <h3>☞</h3>
        </button>
        </div>
      </form>
      {loading && <p>Loading...</p>}
      {washer && (
        <div className="card">
          <div className="card-body">
            <p className="card-text">Unique Id: {washer.id}</p>
            
          </div>
        </div>
      )}
    </div>
  );
};

export default GetEmailByIdWasher;
