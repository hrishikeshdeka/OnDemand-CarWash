import React, { useState } from "react";
import axios from "axios";
import ANavbar from "../ANavbar";
import GetEmailByIdWasher from "./GetEmailByIdWasher";
import Footer from "../Footer";
import edit from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/account-concept-illustration_114360-5201.avif';
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/EditProfile.css';

const EditProfileWasher = () => {
  const [id, setId] = useState("");
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.put(
        `http://localhost:9001/api/washer/update/${id}`,
        {
          firstname,
          lastname,
          email,
          phone,
          password,
        }
      );

      const updatedWasher = response.data;
      console.log("Updated Washer:", updatedWasher);

      alert("You have successfully edited your details.");
    } catch (error) {
      console.error("Error updating Washer:", error);
    }
  };

  const handleDeleteProfile = async () => {
    try {
      await axios.delete(`http://localhost:9001/api/washer/${id}`);
      alert("Washer profile deleted successfully.");
    } catch (error) {
      console.error("Error deleting washer profile:", error);
    }
  };

  return (
    <div>
      <ANavbar />
      <div className="container">
        <div className="row justify-content-left">
          <div className="col-lg-6">
            <img
              src={edit}
              alt="Image1"
              className="img-fluid"
              style={{ width: "100%", height: "auto" }}
            />
          </div>
          <div className="col-lg-6">
            <p></p>
            <p></p>
            <p></p>
            <p></p>
            <GetEmailByIdWasher />
            <h2 style={{ fontFamily: "Pacifico" }}>Edit Washer Details 👇🏼 :</h2>
            <form onSubmit={handleFormSubmit}>
              <div className="form-group">
                <label htmlFor="id">ID:</label>
                <input
                  type="text"
                  id="id"
                  value={id}
                  onChange={(e) => setId(e.target.value)}
                  required
                  className="form-control rounded"
                />
              </div>

              <div className="form-group">
                <label htmlFor="firstname">First Name:</label>
                <input
                  type="text"
                  id="firstname"
                  value={firstname}
                  onChange={(e) => setFirstname(e.target.value)}
                  required
                  className="form-control rounded"
                />
              </div>

              <div className="form-group">
                <label htmlFor="lastname">Last Name:</label>
                <input
                  type="text"
                  id="lastname"
                  value={lastname}
                  onChange={(e) => setLastname(e.target.value)}
                  required
                  className="form-control rounded"
                />
              </div>

              <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="form-control rounded"
                />
              </div>

              <div className="form-group">
                <label htmlFor="phone">Phone Number:</label>
                <input
                  type="phone"
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  className="form-control rounded"
                />
              </div>

              <div className="form-group">
                <label htmlFor="password">Password:</label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="form-control rounded"
                />
              </div>

              <button type="submit" className="btn btn-primary">
                Update Washer
              </button>
            </form>
            <form>
            <div className="form-group">
                <label htmlFor="id">ID:</label>
                <input
                  type="text"
                  id="id"
                  value={id}
                  onChange={(e) => setId(e.target.value)}
                  required
                  className="form-control rounded"
                />
              </div>
            </form>
            <button onClick={handleDeleteProfile} className="btn btn-danger mt-3">
              Delete Profile
            </button>
            <h1 style={{ color: "white" }}>.</h1>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default EditProfileWasher;
