import React, { useState } from "react";
import axios from "axios";
import ANavbar from "../ANavbar";
import GetEmailByIdWasher from "./GetEmailByIdWasher";
import Footer from "../Footer";
import pic1 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/appointment-booking-with-smartphone_23-2148563698.avif';

const WasherOrderHistory = () => {
  const [washerId, setWasherId] = useState("");
  const [washerData, setWasherData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedBooking, setSelectedBooking] = useState(null);

  const fetchWasherData = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await axios.get(
        `http://localhost:9002/api/booking/bookings-washer/${washerId}`
      );
      setWasherData(response.data);
      setSelectedBooking(null); // Reset selected booking
    } catch (error) {
      setError("Error fetching washer data.");
    }

    setIsLoading(false);
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    fetchWasherData();
  };

  const handleBookingSelect = (bookingId) => {
    if (bookingId === selectedBooking) {
      // If already selected, deselect the booking
      setSelectedBooking(null);
    } else {
      setSelectedBooking(bookingId);
    }
  };

  return (
    <div>
      <ANavbar />
      <div className="container">
        <div className="row">
          <div className="col-lg-6">
            <div>
            </div>
            <div>
              <p style={{ color: "white" }}>.</p>
            </div>
            <div>
              <GetEmailByIdWasher />
              <p style={{ color: "white" }}>.</p>
            </div>
            <h2 style={{ fontFamily: "Pacifico" }}>
              Washer Bookings History 👇🏼:
            </h2>
            <form onSubmit={handleFormSubmit}>
              <div className="form-group">
                <label htmlFor="washerId">Washer ID:</label>
                <input
                  type="text"
                  id="washerId"
                  value={washerId}
                  onChange={(e) => setWasherId(e.target.value)}
                  required
                  className="form-control"
                />
              </div>
              <button type="submit" className="btn btn-primary">
                Fetch Washer Bookings
              </button>
            </form>

            {isLoading && <p>Loading...</p>}
            {error && <p>{error}</p>}
            {washerData && (
              <div>
                <h4>Washer Information:</h4>
                <p>Washer ID: {washerData.washer.id}</p>
                <p>Washer Name: {washerData.washer.name}</p>

                <h4>Bookings:</h4>
                {washerData.bookings.map((booking) => (
                  <div key={booking.id}>
                    <button
                      type="button"
                      className="btn btn-link"
                      data-bs-toggle="modal"
                      data-bs-target={`#bookingModal-${booking.id}`}
                    >
                      Booking ID: {booking.id}
                    </button>
                    <div
                      className="modal fade"
                      id={`bookingModal-${booking.id}`}
                      tabIndex="-1"
                      aria-labelledby={`bookingModalLabel-${booking.id}`}
                      aria-hidden="true"
                    >
                      <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                          <div className="modal-header">
                            <h5
                              className="modal-title"
                              id={`bookingModalLabel-${booking.id}`}
                            >
                              Booking Details
                            </h5>
                            <button
                              type="button"
                              className="btn-close"
                              data-bs-dismiss="modal"
                              aria-label="Close"
                              onClick={() => handleBookingSelect(null)}
                            ></button>
                          </div>
                          <div className="modal-body">
                            <p>Car Name: {booking.carName}</p>
                            <p>Address: {booking.address}</p>
                            <p>Package Name: {booking.packName}</p>
                            <p>Date: {booking.date}</p>
                            <p>Time: {booking.time}</p>
                            <p>User: {booking.userId}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="col-lg-6">
            <img
              src={pic1}
              alt="Car"
              className="img-fluid"
              style={{ width: "100%" }}
            />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default WasherOrderHistory;
