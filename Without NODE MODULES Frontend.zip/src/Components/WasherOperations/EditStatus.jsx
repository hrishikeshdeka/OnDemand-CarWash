import React, { useState } from "react";
import axios from "axios";
import ANavbar from "../ANavbar";
import GetEmailByIdWasher from "./GetEmailByIdWasher";
import Footer from "../Footer";
import Status from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/buffer-concept-illustration_114360-2267.avif';
const EditStatus = () => {
  const [id, setId] = useState("");
  const [status, setStatus] = useState("");

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios.put(`http://localhost:9001/api/washer/update/status/${id}`, {
        status,
      });

      alert("Status updated successfully.");
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  return (
    <div>
      <ANavbar />

      <div className="container">
        <div className="row justify-content-left">
          <div className="col-lg-6">
          <h1 style={{ color: "white" }}>.</h1>
            <img
              src={Status}
              alt="Image1"
              className="img-fluid"
            />
          </div>
          <div className="col-lg-6">
          <div>
          <h1 style={{ color: "white" }}>.</h1>
          <h1 style={{ color: "white" }}>.</h1>
          <h1 style={{ color: "white" }}>.</h1>
        <GetEmailByIdWasher />
      </div>
      
            <h2>Edit Washer</h2>
            <form onSubmit={handleFormSubmit}>
              <div className="form-group">
                <label htmlFor="id">ID:</label>
                <input
                  type="text"
                  id="id"
                  value={id}
                  onChange={(e) => setId(e.target.value)}
                  required
                  className="form-control"
                />
              </div>

              <div className="form-group">
                <label htmlFor="status">Status:</label>
                <select
                  id="status"
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  required
                  className="form-control"
                >
                  <option value="">Select status</option>
                  <option value="AVAILABLE">Available</option>
                  <option value="BUSY">Busy</option>
                  <option value="OFFLINE">Offline</option>
                </select>
              </div>

              <button type="submit" className="btn btn-primary">
                Update Status
              </button>
            </form>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default EditStatus;
