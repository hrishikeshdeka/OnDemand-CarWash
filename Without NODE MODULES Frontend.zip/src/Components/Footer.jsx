import React from 'react';
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/Footer.css';
const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer__addr">
        <h1 className="footer__logo">WHEELS WASH</h1>

        <address>
          NH-37 , B.R.Deka Path , Guwahati , Assam<br />
 
        </address>
      </div>
      <div className="legal">
        <p>&copy; 2023 Copyright.</p>
      </div>
    </footer>
  );
};

export default Footer;
