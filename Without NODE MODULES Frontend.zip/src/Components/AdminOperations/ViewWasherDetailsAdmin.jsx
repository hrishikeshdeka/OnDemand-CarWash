import React, { useEffect, useState } from "react";
import axios from "axios";
import ANavbar from "../ANavbar";
import Footer from "../Footer";
import backgroundImage from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/curiosity-search-concept-illustration_114360-11031.avif';
import ViewWasherByID from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/AdminOperations/ViewWasherByID.jsx';
export default function ViewWasherDetails() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await axios.get("http://localhost:9003/api/admin/washer/all");
    setUsers(result.data);
  };

  const deleteUser = async (id) => {
    await axios.delete(`http://localhost:9003/api/admin/washers/delete/${id}`);
    loadUsers();
  };

  return (
    <div>
    <ANavbar />
    <div className="container">
      <div className="py-4">
     
      <h2 style={{ fontFamily: "Pacifico" }}>Washer List 👇🏼 :</h2>
        <table className="table border shadow">
          <thead>
            <tr>
              <th scope="col">S.No:</th>
              <th scope="col">Washer ID:</th>
              <th scope="col">Firstname:</th>
              <th scope="col">Lastname:</th>
              <th scope="col">Phone:</th>
              <th scope="col">Email:</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr key={index}>
                <th scope="row">{index + 1}</th>
                <td>{user.id}</td>
                <td>{user.firstname}</td>
                <td>{user.lastname}</td>
                <td>{user.email}</td>
                <td>{user.phone}</td>
                <td>
                  <button
                    className="btn btn-danger mx-2"
                    onClick={() => deleteUser(user.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <ViewWasherByID/>
      </div>
      <div id="carouselExample" className="carousel slide">
              <div className="carousel-inner">
                <div className="carousel-item active">
                  <img src={backgroundImage} className="d-block w-100" alt="1st" />
                </div>
              </div>
            </div>
    </div>
    <Footer/>
  </div>
);
}
