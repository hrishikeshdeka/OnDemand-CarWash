import React, { useState, useEffect } from "react";
import axios from "axios";
import { Button, Modal } from "react-bootstrap";

const EditServices = ({ washpackId }) => {
  const [washPack, setWashPack] = useState({
    washpackId: "",
    washPackName: "",
    washPackPrice: "",
    washPackDesc: ""
  });
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    fetchWashPack();
  }, [washpackId]);

  const fetchWashPack = async () => {
    try {
      const response = await axios.get(
        `http://localhost:9003/api/admin/washpacks/${washpackId}`
      );
      setWashPack(response.data);
    } catch (error) {
      console.error("Error fetching wash pack:", error);
    }
  };

  const handleChange = (e) => {
    setWashPack({
      ...washPack,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(
        `http://localhost:9003/api/admin/washpacks/${washpackId}`,
        washPack
      );
      console.log("Wash pack updated successfully");
      handleCloseModal();
    } catch (error) {
      console.error("Error updating wash pack:", error);
    }
  };

  const handleShowModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  return (
    <div>

<Button variant="primary" onClick={handleShowModal} className="btn btn-primary mx-2">
  Edit
</Button>

      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Services</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label htmlFor="washPackName" className="form-label">
                Wash Pack Name
              </label>
              <input
                type="text"
                className="form-control"
                id="washPackName"
                name="washPackName"
                value={washPack.washPackName}
                onChange={handleChange}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="washPackPrice" className="form-label">
                Wash Pack Price
              </label>
              <input
                type="text"
                className="form-control"
                id="washPackPrice"
                name="washPackPrice"
                value={washPack.washPackPrice}
                onChange={handleChange}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="washPackDesc" className="form-label">
                Wash Pack Description
              </label>
              <textarea
                className="form-control"
                id="washPackDesc"
                name="washPackDesc"
                value={washPack.washPackDesc}
                onChange={handleChange}
                required
              ></textarea>
            </div>
            <Button variant="primary" type="submit">
              Update
            </Button>
          </form>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default EditServices;
