import React, { useEffect, useState } from "react";
import axios from "axios";
import ANavbar from "../ANavbar";
import Footer from "../Footer";
import EditServices from "./EditServices";

export default function ManageServices() {
  const [services, setServices] = useState([]);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    const result = await axios.get(
      `http://localhost:9003/api/admin/washpacks/all`
    );
    setServices(result.data);
  };

  const deleteServices = async (washpackId) => {
    await axios.delete(
      `http://localhost:9003/api/admin/washpacks/delete/${washpackId}`
    );
    loadServices();
  };

  return (
    <div>
      <ANavbar />

      <div className="container">
        <div className="py-4">
          <h2 style={{ fontFamily: "Pacifico" }}>Services List 👇🏼 :</h2>
          <table className="table border shadow">
            <thead>
              <tr>
                <th scope="col">S.No. :</th>
                <th scope="col">Service ID:</th>
                <th scope="col">Service Name :</th>
                <th scope="col">Service Price :</th>
                <th scope="col">Service Description :</th>
                <th scope="col">Actions :</th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
              {services.map((service, index) => (
                <tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{service.washpackId}</td>
                  <td>{service.washPackName}</td>
                  <td>{service.washPackPrice}</td>
                  <td>{service.washPackDesc}</td>
                  <td>
                    <button
                      className="btn btn-danger mx-2"
                      onClick={() => deleteServices(service.washpackId)}
                    >
                      Delete
                    </button>
                    <br/>

                  </td>
                  <td><EditServices washpackId={service.washpackId} /> </td>
                
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <h1 style={{ color: "white" }}>.</h1>
      <h5 style={{ color: "white" }}>.</h5>
      <Footer />
    </div>
  );
}
