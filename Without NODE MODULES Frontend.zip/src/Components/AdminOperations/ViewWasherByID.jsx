import React, { useState } from "react";
import axios from "axios";
import { Modal, Button } from "react-bootstrap";

const ViewBookingByWasherID = () => {
  const [washerId, setWasherId] = useState("");
  const [washerData, setWasherData] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const fetchWasherAndBookings = async () => {
    try {
      const response = await axios.get(`http://localhost:9002/api/booking/bookings-washer/${washerId}`);
      setWasherData(response.data);
      setShowModal(true);
    } catch (error) {
      console.error("Error fetching washer and bookings:", error);
    }
  };

  const handleWasherIdChange = (e) => {
    setWasherId(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchWasherAndBookings();
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={washerId}
          onChange={handleWasherIdChange}
          placeholder="Fetch Bookings by Washer ID"
          style={{ borderRadius: '12px', width: '270px', height: '50px' }}
        />
        <button
          type="submit"
          className="submit-button"
          style={{ borderRadius: '12px', width: '50px', height: '50px' }}
        >
          <h3>☞</h3>
        </button>
      </form>

      {washerData && (
        <Modal show={showModal} onHide={handleCloseModal}>
          <Modal.Header closeButton>
            <Modal.Title>Booking Details</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <p>Washer ID: {washerData.washer.id}</p>
            <p>Washer Name: {washerData.washer.name}</p>
            <p><strong>Bookings:</strong></p>
            <ul>
              {washerData.bookings.map((booking) => (
                <li key={booking.id}>
                  <strong>Booking ID:</strong> {booking.id} <br />
                  <b>Car Name: </b> {booking.carName} <br />
                  <b>Address: </b> {booking.address} <br />
                  <b>Service: </b> {booking.packName} <br />
                  <b>Date: </b> {booking.date} <br />
                  <b>User Serving (User ID): </b> {booking.userId} <br />
                  <b>Booking Status: </b> {booking.bookingStatus}
                </li>
              ))}
            </ul>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCloseModal}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      )}
    </div>
  );
};

export default ViewBookingByWasherID;
