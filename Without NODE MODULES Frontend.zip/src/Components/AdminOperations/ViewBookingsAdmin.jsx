import React, { useEffect, useState } from "react";
import axios from "axios";
import ANavbar from "../ANavbar";
import Footer from "../Footer";
import ViewBookingByUserId from "./ViewBookingByuserId";

export default function ViewWasherDetails() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await axios.get(
      `http://localhost:9003/api/admin/bookings/all`
    );
    setUsers(result.data);
  };

  const deleteUser = async (id) => {
    await axios.delete(`http://localhost:9003/api/admin/bookings/delete/${id}`);
    loadUsers();
  };

  return (
    <div>
      <ANavbar />
      
      <div className="container">
        <div className="py-4">
        
        <h2 style={{ fontFamily: "Pacifico" }}>Bookings List 👇🏼 :</h2>
          <table className="table border shadow">
            <thead>
              <tr>
                <th scope="col">S.No. :</th>
                <th scope="col">Booking ID:</th>
                <th scope="col">Car Name :</th>
                <th scope="col">Address :</th>
                <th scope="col">Service Availed :</th>
                <th scope="col">Date :</th>
                <th scope="col">Time:</th>
                <th scope="col">User ID:</th>
                <th scope="col">Washer ID:</th>
                <th scope="col">Booking Status:</th>
                <th scope="col">Action:</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user, index) => (
                <tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{user.id}</td>
                  <td>{user.carName}</td>
                  <td>{user.address}</td>
                  <td>{user.packName}</td>
                  <td>{user.date}</td>
                  <td>{user.time}</td>
                  <td>{user.userId}</td>
                  <td>{user.washerId}</td>
                  <td>{user.bookingStatus}</td>
                  <td>
                    <button
                      className="btn btn-danger mx-2"
                      onClick={() => deleteUser(user.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <ViewBookingByUserId/>
        </div>
      </div>
      <h1 style={{ color: "white" }}>.</h1>
      <h5 style={{ color: "white" }}>.</h5>
      <Footer/>
    </div>
  );
}
