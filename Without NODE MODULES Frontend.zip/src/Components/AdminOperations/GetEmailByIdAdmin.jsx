import React from 'react'

function GetEmailByIdAdmin() {
  return (
    <div>GetEmailByIdAdmin</div>
  )
}

export default GetEmailByIdAdmin