import React, { useState } from "react";
import axios from "axios";
import { Modal, Button } from "react-bootstrap";

const ViewBookingByUserId = () => {
  const [userId, setUserId] = useState("");
  const [userData, setUserData] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const fetchUserAndBookings = async () => {
    try {
      const response = await axios.get(`http://localhost:9002/api/booking/bookings-user/${userId}`);
      setUserData(response.data);
      setShowModal(true);
    } catch (error) {
      console.error("Error fetching user and bookings:", error);
    }
  };

  const handleUserIdChange = (e) => {
    setUserId(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchUserAndBookings();
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  return (
    <div>
     <form onSubmit={handleSubmit}>
  <input
    type="text"
    value={userId}
    onChange={handleUserIdChange}
    placeholder="Fetch Booking by User's ID"
    style={{ borderRadius: '12px', width: '270px', height: '50px' }}
  />

  <button
    type="submit"
    className="submit-button"
    style={{ borderRadius: '12px', width: '50px', height: '50px' }}
  >
    <h3>☞</h3>
  </button>
</form>

      {userData && (
        <Modal show={showModal} onHide={handleCloseModal}>
          <Modal.Header closeButton>
            <Modal.Title>Booking Details 👇🏼 </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <p>User Name: {userData.user.firstname} {userData.user.lastname}</p>
            <p>Email: {userData.user.email}</p>
            <p>Phone: {userData.user.phone}</p>
            <p><strong>Bookings:</strong></p>
            <ul>
              {userData.bookings.map((booking) => (
                <li key={booking.id}>
                  <strong>Booking ID:</strong> {booking.id} <br />
                  <b>Car Name: </b> {booking.carName}
                  <br />
                  <b>Address: </b> {booking.address}
                  <br />
                  <b>Service: </b>{booking.packName}
                  <br />
                  <b>Date: </b>{booking.date}
               
                  <br />
                  <b>Washer Assigned(Washer ID): </b> {booking.washerId}
                  <br />
                  <b>Booking Status : </b> {booking.bookingStatus}
                </li>
              ))}
            </ul>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCloseModal}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      )}
    </div>
  );
};

export default ViewBookingByUserId;
