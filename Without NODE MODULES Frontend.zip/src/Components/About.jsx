import React from 'react';
import image from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/Screenshot 2023-07-09 at 6.16.23 AM.png';
import Navbar from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Navbar.jsx';
import Footer from './Footer';
const About = () => {
  return (
        <div><Navbar/>
    <div id="carouselExample" className="carousel slide">
      <div className="carousel-inner">
        <div className="carousel-item active">
          <img src={image} className="d-block w-100" alt="1st" />
        </div>
      </div>
    </div>
    <Footer/>
    </div>
  );
}

export default About;
