import React, { useState } from "react";
import carImg1 from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/landing-main.jpg";
import carImg2 from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/1.001.jpg";
import carImg3 from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/1.jpg.001.jpeg";
import carImg4 from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/car.jpeg";
import pic1 from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/Screenshot 2023-07-08 at 12.26.09 PM.png";
import pic2 from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/Screenshot 2023-07-08 at 12.16.49 PM.png";
import Navbar from "./Navbar";
import "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/Landing.css"; // Import the external CSS file
import Footer from "./Footer";
import DatePicker from "react-datepicker";
import TimePicker from "react-time-picker";
import { useNavigate } from "react-router-dom";
const Landing = () => {
  const [formValues, setFormValues] = useState({
    email: "",
    carName: "",
    address: "",
    packName: "",
    date: "",
    time: "",
  });

  const navigate = useNavigate();

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform form submission logic here
    // Redirect to "/login" after submission
    navigate("/login");
  };
  return (
    <div>
      <div className="carousel">
        <div data-testid="navbar">
          <Navbar />
        </div>
        <div id="carouselExample" className="carousel slide">
          <div className="carousel-inner">
            <div className="carousel-item active">
              <img src={carImg1} className="d-block w-100" alt="Image1" />
            </div>
            <div className="carousel-item">
              <img src={carImg2} className="d-block w-100" alt="Image2" />
            </div>
            <div className="carousel-item">
              <img src={carImg3} className="d-block w-100" alt="Image3" />
            </div>
            <div className="carousel-item">
              <img src={carImg4} className="d-block w-100" alt="Image4" />
            </div>
          </div>
          <button
            className="carousel-control-prev"
            type="button"
            data-bs-target="#carouselExample"
            data-bs-slide="prev"
          >
            <span
              className="carousel-control-prev-icon"
              aria-hidden="true"
            ></span>
            <span className="visually-hidden">Previous</span>
          </button>
          <button
            className="carousel-control-next"
            type="button"
            data-bs-target="#carouselExample"
            data-bs-slide="next"
          >
            <span
              className="carousel-control-next-icon"
              aria-hidden="true"
            ></span>
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </div>

      <div>
        <div className="container text-center">
          <div className="row align-items-start">
            <div className="col-7 pt-4 text-start">
              <img src={pic2} alt="Car" className="rounded img-fluid" />
              <img src={pic1} alt="Car" className="rounded img-fluid" />
            </div>
            <div className="col-5 pt-5">
              <form
                style={{
                  backgroundColor: "#FFFFFF",
                  padding: "20px",
                  borderRadius: "10px",
                  textAlign: "left",
                }}
                onSubmit={handleSubmit}
              >
                <div className="mb-3">
                  <label
                    htmlFor="email"
                    className={`form-label ${
                      formValues.email ? "float-label" : ""
                    }`
                    }
                  >
                    Email
                  </label>
                  <input
                    type="text"
                    className={`form-control rounded ${
                      formValues.email ? "has-value" : ""
                    }`}
                    id="email"
                    name="email"
                    value={formValues.email}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="mb-3">
                  <label
                    htmlFor="carName"
                    className={`form-label ${
                      formValues.carName ? "float-label" : ""
                    }`}
                  >
                    Car Name
                  </label>
                  <input
                    type="text"
                    className={`form-control rounded ${
                      formValues.carName ? "has-value" : ""
                    }`}
                    id="carName"
                    name="carName"
                    value={formValues.carName}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="mb-3">
                  <label
                    htmlFor="address"
                    className={`form-label ${
                      formValues.address ? "float-label" : ""
                    }`}
                  >
                    Address
                  </label>
                  <input
                    type="text"
                    className={`form-control rounded ${
                      formValues.address ? "has-value" : ""
                    }`}
                    id="address"
                    name="address"
                    value={formValues.address}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="mb-3">
                  <label
                    htmlFor="packName"
                    className={`form-label ${
                      formValues.packName ? "float-label" : ""
                    }`}
                  >
                    Select Service
                  </label>
                  <select
                    id="packName"
                    className={`form-control rounded ${
                      formValues.packName ? "has-value" : ""
                    }`}
                    name="packName"
                    value={formValues.packName}
                    onChange={handleInputChange}
                  >
                    <option value="">Select a Service</option>
                    <option value="Silver Wash">Silver Wash</option>
                    <option value="Gold Wash">Gold Wash</option>
                    <option value="Platinum Wash">Platinum Wash</option>
                    <option value="Basic Internal Cleaning">
                      Basic Internal Cleaning
                    </option>
                    <option value="Intense Internal Cleaning">
                      Intense Internal Cleaning
                    </option>
                    <option value="Wax Rubbing And Buffing">
                      Wax Rubbing And Buffing
                    </option>
                    <option value="Teflon Coating">Teflon Coating</option>
                    <option value="WindSheild Treatment">
                      WindSheild Treatment
                    </option>
                    <option value="Leather Conditioning">
                      Leather Conditioning
                    </option>
                  </select>
                </div>

                <div className="mb-3">
                  <label
                    htmlFor="date"
                    className={`form-label ${
                      formValues.date ? "float-label" : ""
                    }`}
                  >
                    Select Date:
                  </label>
                  <DatePicker
                    id="date"
                    selected={formValues.date}
                    onChange={(date) => setFormValues({ ...formValues, date })}
                    minDate={new Date()}
                    dateFormat="dd/MM/yy"
                    className="form-control"
                    required
                  />
                </div>

                <div className="mb-3">
                  <label
                    htmlFor="time"
                    className={`form-label ${
                      formValues.time ? "float-label" : ""
                    
                    }`}
                  >
                    Time:
                  </label>
                  <TimePicker
                    id="time"
                    value={formValues.time}
                    onChange={(time) => setFormValues({ ...formValues, time })}
                    format="hh:mm a"
                    className="form-control"
                    required
                  />
                </div>
                <button type="submit" className="btn btn-primary">
                  Submit
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div data-testid="footer">
      <Footer />
      </div>
  
    </div>
  );
};

export default Landing;
