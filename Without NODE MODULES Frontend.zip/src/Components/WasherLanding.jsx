import React from 'react';
import { Link } from 'react-router-dom';
import carImg1 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/Screenshot 2023-07-08 at 11.22.11 PM.png';
import ANavbar from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/ANavbar.jsx';
import Footer from './Footer';
import manage from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/personal-settings-concept-illustration_114360-2251.avif';
import status from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/relationship-status-abstract-illustration_335657-5425.avif';
import services from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/car-wash-service-symbols-flat-icons-collection-with-windshield-squeegee-soap-cannon_1284-10240.avif';
import booking from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/appointment-booking-with-smartphone-man_23-2148576384.avif';

const WasherLanding = () => {
  return (
    <div className="whitesmoke-bg">
      <div data-testid="anavbar">
      <ANavbar/>
      </div>
      <div id="carouselExample" className="carousel slide" data-bs-ride="carousel" role="region" aria-label="carousel">
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src={carImg1} className="d-block w-100" alt="Carousel" />
          </div>
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
        </div>
        <h2 style={{ fontFamily: "Pacifico"}}>.</h2>
      <div className="card-container">
      
        <div className="card">
          <img src={manage} className="card-img-top" alt="image1" />
          <div className="card-body">
            <h5 className="card-title">Manage Profile 🥹</h5>
            <p className="card-text">
              View and manage your profile with a simple click.
            </p>
            <Link to="/login/washer/manage-profile" className="btn btn-primary">
              Click Here
            </Link>
          </div>
        </div>
        <div className="card">
          <img src={status} className="card-img-top" alt="image2" />
          <div className="card-body">
            <h5 className="card-title">Set Your Status</h5>
            <p className="card-text">
              Edit your profile status so that our customers can know if you are available or not.
            </p>
            <Link to="/login/washer/update-status" className="btn btn-primary">
              Click Here
            </Link>
          </div>
        </div>
        <div className="card">
          <img src={services} className="card-img-top" alt="image2" />
          <div className="card-body">
            <h5 className="card-title">View Services</h5>
            <p className="card-text">
              Check out the services you are required to provide.
            </p>
            <Link to="/login/washer/washer-services" className="btn btn-primary">
              Click Here
            </Link>
          </div>
        </div>
        <div className="card">
          <img src={booking} className="card-img-top" alt="image2" />
          <div className="card-body">
            <h5 className="card-title">View Bookings</h5>
            <p className="card-text">
              Shows your booking information and your previous booking histories.
            </p>
            <Link to="/login/washer/washer-bookings" className="btn btn-primary">
              Click Here
            </Link>
          </div>
        </div>
      </div>
      <h2 style={{ fontFamily: "Pacifico"}}>.</h2>
      <div data-testid="footer">
    <Footer/>
    </div>
    </div>
  );
};

export default WasherLanding;
