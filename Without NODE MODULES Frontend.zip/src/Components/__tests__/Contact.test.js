import React from 'react';
import { render} from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Contact from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Contact.jsx';


test('renders Landing component', () => {
    render(
      <BrowserRouter>
        <Contact/>
      </BrowserRouter>
    );
});