import React from 'react';
import { render,screen} from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Landing from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Landing.jsx';

test('renders Landing component', () => {
  render(
    <BrowserRouter>
      <Landing />
    </BrowserRouter>
  );
  const navbarElement = screen.getByTestId('navbar');

  expect(navbarElement).toBeInTheDocument();


  const footerElement= screen.getByTestId('footer');
  expect(footerElement).toBeInTheDocument();
});


