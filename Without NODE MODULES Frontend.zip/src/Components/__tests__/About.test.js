import React from 'react';
import { render,screen} from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import About from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/About.jsx';
test('renders Landing component', () => {
    render(
      <BrowserRouter>
        <About />
      </BrowserRouter>
    );
});