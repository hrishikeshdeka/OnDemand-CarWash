import React from 'react';
import { render} from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Navbar from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Navbar.jsx';
test('renders navbar component', () => {
    render(
      <BrowserRouter>
        <Navbar />
      </BrowserRouter>
    );
});