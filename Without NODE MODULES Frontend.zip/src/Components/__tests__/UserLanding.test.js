import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import UserLanding from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/UserLanding.jsx';

test('renders UserLanding component', () => {
  render(
    <BrowserRouter>
      <UserLanding />
    </BrowserRouter>
  );
  const navbarElement = screen.getByTestId('anavbar');
  expect(navbarElement).toBeInTheDocument();

  const carouselElement = screen.getByRole('region', { name: 'carousel' });
  expect(carouselElement).toBeInTheDocument();


  const footerElement= screen.getByTestId('footer');
  expect(footerElement).toBeInTheDocument();
});
