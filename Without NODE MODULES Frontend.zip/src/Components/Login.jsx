import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";

export const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Check if any field is empty
    if (!email || !password || !role) {
      alert("Please fill in all fields."); // Display an alert
      return; // Stop further execution
    }

    const loginData = {
      email: email,
      password: password,
    };

    let url = "";
    let redirectUrl = ""; // URL to redirect based on role

    if (role === "user") {
      url = "http://localhost:9000/api/authenticate"; 
    
      redirectUrl = "/login/user";
      // Redirect to UserLanding
    } else if (role === "washer") {
      url = "http://localhost:9001/api/washer/login";
      console.log(url)
      redirectUrl = "/login/washer"; 
    }
    else if(role === "admin"){
      url = "http://localhost:9000/api/authenticate/admin"; 
    
      redirectUrl = "/login/admin";
    }

    try {
      const response = await axios.post(url, loginData);
      console.log(response.data); 

      // Redirect based on the role
      if (response.status === 200) {
        navigate(redirectUrl);
      }
    } catch (error) {
      if (error.response) {
        if (error.response.status === 403) {
          alert("Invalid credentials. Please try again.");
        } else {
          alert("An error occurred. Please try again later.");
        }
      } else if (error.request) {
        // The request was made but no response was received
        alert("No response received. Please check your internet connection.");
      } else {
        // Something else happened in making the request
        alert("An error occurred. Please try again later.");
      }
    }
  };

  const handleRoleChange = (e) => {
    setRole(e.target.value);
  };

  return (
    <div>
      <Navbar />
      <div className="auth-form-container">
        <form className="register-form" onSubmit={handleSubmit}>
          <h2>Login</h2>
          <div style={{ marginBottom: "10px" }}>
            <label htmlFor="email" style={{ fontWeight: "normal" }}>
              Email
            </label>
          </div>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            id="email"
            name="email"
            placeholder="youremail@gmail.com"
            required
          />
          <div style={{ marginBottom: "10px" }}>
            <label htmlFor="password" style={{ fontWeight: "normal" }}>
              Password
            </label>
          </div>
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            id="password"
            name="password"
            placeholder="password"
            required
            minLength="1"
          />
          <div className="container">
            <select className="role-dropdown" onChange={handleRoleChange}>
              <option value="">-- Select a Role --</option>
              <option value="user">User</option>
              <option value="washer">Washer</option>
              <option value="admin"> Admin</option>
            </select>
          </div>
          <button type="submit">Login</button>
        </form>
      </div>
      <Footer/>
    </div>
  );
};
