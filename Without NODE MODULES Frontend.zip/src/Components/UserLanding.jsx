import React from 'react';
import { Link } from 'react-router-dom';
import carImg1 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/manage_profile.jpg';
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/UserLanding.css';
import ANavbar from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/ANavbar.jsx';
import Footer from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Footer.jsx';
import pic1 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/Screenshot 2023-07-08 at 12.53.42 PM.png';
import bookingImg from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/3902762.jpg';
import serviceImg from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/car-wash-service-symbols-flat-icons-collection-with-windshield-squeegee-soap-cannon_1284-10240.avif';
import bookingImg2 from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/appointment-booking-with-calendar_23-2148556782.avif';
const UserLanding = () => {
  return (
    <div > 
      <div data-testid="anavbar">
      <ANavbar/>
      </div>
     <div id="carouselExample" className="carousel slide" data-bs-ride="carousel" role="region" aria-label="carousel">
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src={pic1} className="d-block w-100" alt="Carousel" />
          </div>
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>
    <div className="card-container">
      <div className="card">
        <img src={carImg1} className="card-img-top" alt="image1" />
        <div className="card-body">
          <h5 className="card-title">Manage Profile 😄</h5>
          <p className="card-text">
            View and manage your profile with a simple click.
          </p>
          <Link to="/login/user/manage-profile" className="btn btn-info">
            Click Here
          </Link>
        </div>
      </div>
      <div className="card">
        <img src={bookingImg} className="card-img-top" alt="image2" />
        <div className="card-body">
          <h5 className="card-title">Book A Wash 🧼 </h5>
          <p className="card-text">
            Book according to your profile with a simple click.
          </p>
          <Link to="/login/user/booking-operations" className="btn btn-info">
            Click Here
          </Link>
        </div>
      </div>
      <div className="card">
        <img src={serviceImg} className="card-img-top" alt="image2" />
        <div className="card-body">
          <h5 className="card-title">View Washpacks and Services 🔩 </h5>
          <p className="card-text">
            View the washpacks and services we provide.
          </p>
          <Link to="/login/user/view-services" className="btn btn-info">
            Click Here
          </Link>
        </div>
      </div>
      <div className="card">
        <img src={bookingImg2} className="card-img-top" alt="image2" />
        <div className="card-body">
          <h5 className="card-title">View Booking History 📜 </h5>
          <p className="card-text">
            View all your previous bookings, with a simple click.
          </p>
          <Link to="/login/user/user-bookings" className="btn btn-info">
            Click Here
          </Link>
        </div>
      </div>
    </div>
    <div data-testid="footer">
    <Footer/>
    </div>
    </div>
  );
};

export default UserLanding;
