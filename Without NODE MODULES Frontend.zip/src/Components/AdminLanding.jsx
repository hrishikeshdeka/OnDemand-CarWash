import React from 'react';
import { Link } from 'react-router-dom';
import main from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/Screenshot 2023-07-09 at 12.52.26 AM.png';
import ANavbar from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/ANavbar.jsx';
import Footer from './Footer';
import Ser from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/noctidial-technical-support-online-assistant-user-help-frequently-asked-questions-call-center-worker-cartoon-character-woman-working-hotline_335657-782.avif';
import UserPic from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/remote-management-distant-work-isometric-icons-composition-with-man-computer-table-with-avatars-distant-workers_1284-63071.avif';
import WasherPic from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/follow-me-social-business-theme-design_24877-52233.jpg';
import BookingPic from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/car-wash-service-symbols-flat-icons-collection-with-windshield-squeegee-soap-cannon_1284-10240.avif';
const AdminLanding = () => {
  return (
    <div className="whitesmoke-bg">
      <ANavbar />
      <div id="carouselExample" className="carousel slide" data-bs-ride="carousel">
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src={main} className="d-block w-100" alt="Carousel" />
          </div>
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>
      <h2 style={{ fontFamily: "Pacifico" }}>.</h2>
      <div className="card-container">
        <div className="card">
          <img src={Ser} className="card-img-top" alt="image2" />
          <div className="card-body">
            <h5 className="card-title">Manage Services</h5>
            <p className="card-text">
              Add, edit services, and view the services.
            </p>
            <Link to="/login/admin/manage-services" className="btn btn-primary">
              Click Here
            </Link>
          </div>
        </div>
        <div className="card">
          <img src={WasherPic} className="card-img-top" alt="image2" />
          <div className="card-body">
            <h5 className="card-title">View User Details</h5>
            <p className="card-text">
              View user details and block users.
            </p>
            <Link to="/login/admin/view/user-details" className="btn btn-primary">
              Click Here
            </Link>
          </div>
        </div>
        <div className="card">
          <img src={UserPic} className="card-img-top" alt="image2" />
          <div className="card-body">
            <h5 className="card-title">View Washer Details</h5>
            <p className="card-text">
              View washer details and block washers.
            </p>
            <Link to="/login/admin/view/washer-details" className="btn btn-primary">
              Click Here
            </Link>
          </div>
        </div>
        <div className="card">
          <img src={BookingPic} className="card-img-top" alt="image2" />
          <div className="card-body">
            <h5 className="card-title">View Bookings</h5>
            <p className="card-text">
              View booking details and make bookings.
            </p>
            <Link to="/login/admin/view/booking-details" className="btn btn-primary">
              Click Here
            </Link>
          </div>
        </div>
      </div>
      <h2 style={{ fontFamily: "Pacifico" }}>.</h2>
      <Footer />
    </div>
  );
};

export default AdminLanding;
