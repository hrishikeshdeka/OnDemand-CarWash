import React from 'react';
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/Contact.css';
import backgroundImage from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/5250480.jpg';
import Navbar from './Navbar';
import Footer from './Footer';

const ContactForm = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
    
    window.location.href = 'https://www.google.com';
  };

  return (
    <div>
      <Navbar />
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <div className="form-container">
              <div className="form-content">
                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <h1 style={{ color: "white" }}>.</h1>
                    <h5 style={{ color: "white" }}>.</h5>
                    <h1 style={{ fontFamily: "Pacifico" }}>Contact Us Form:</h1>
                    <h3 style={{ color: "white" }}>.</h3>
                    <label htmlFor="name" className="form-label">Name:</label>
                    <input type="text" id="name" name="name" className="form-control" required />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="email" className="form-label">Email:</label>
                    <input type="email" id="email" name="email" className="form-control" required />
                  </div>
                  <div className="mb-3">
                    <label htmlFor="message" className="form-label">How can I help?</label>
                    <textarea
                      id="message"
                      name="message"
                      placeholder="Enter your message"
                      className="form-control"
                      required
                    ></textarea>
                  </div>
                  <button type="submit" className="btn btn-primary">Submit</button>
                </form>
              </div>
            </div>
          </div>
          <div className="col-lg-6">
            <h1 style={{ color: "white" }}>.</h1>
            <h1 style={{ color: "white" }}>.</h1>
            <div id="carouselExample" className="carousel slide">
              <div className="carousel-inner">
                <div className="carousel-item active">
                  <img src={backgroundImage} className="d-block w-100" alt="1st" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ContactForm;
