import React, { useState } from "react";
import axios from "axios";
import "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/Register.css";
import Navbar from "./Navbar";
import Footer from "./Footer";
export const Register = (props) => {
  const [email, setEmail] = useState("");
  const [password, setPass] = useState("");
  const [firstname, setFName] = useState("");
  const [lastname, setLName] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    const registrationData = {
      firstname: firstname,
      lastname: lastname,
      email: email,
      password: password,
      phone: phone,
    };
  
    let url = "";
    if (role === "user") {
      url = "http://localhost:9000/api/register"; // Replace with your User Microservice URL
    } else if (role === "washer") {
      url = "http://localhost:9001/api/washer/register"; // Replace with your Washer Microservice URL
    }
  
    // Get the JWT token from wherever it's stored (e.g., localStorage, state, etc.)
    const token = localStorage.getItem("token"); // Replace with your actual token retrieval logic
  
    // Set the request headers with the JWT token
    const headers = {
      Authorization: `Bearer ${token}`,
    };
  
    try {
      const response = await axios.post(url, registrationData, { headers });
      console.log(response.data);
      alert("You are registered!");
  
      const storedData = JSON.parse(localStorage.getItem("registrationData")) || [];
      storedData.push(registrationData);
      localStorage.setItem("registrationData", JSON.stringify(storedData));
  
      if (role === "user") {
        const userData = JSON.parse(localStorage.getItem("userData")) || [];
        userData.push(registrationData);
        localStorage.setItem("userData", JSON.stringify(userData));
      } else if (role === "washer") {
        const washerData = JSON.parse(localStorage.getItem("washerData")) || [];
        washerData.push(registrationData);
        localStorage.setItem("washerData", JSON.stringify(washerData));
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleRoleChange = (e) => {
    setRole(e.target.value);
  };

  return (
    <div>
      {" "}
      <Navbar />
      <div className="auth-form-container">
        <form className="register-form" onSubmit={handleSubmit}>
          <h2>Register</h2>
          <div style={{ marginBottom: "10px" }}>
            <label htmlFor="firstname" style={{ fontWeight: "normal" }}>
              First Name
            </label>
          </div>
          <input
            value={firstname}
            name="firstname"
            onChange={(e) => setFName(e.target.value)}
            id="firstname"
            required
          />
          <div style={{ marginBottom: "10px" }}>
            <label htmlFor="lastname" style={{ fontWeight: "normal" }}>
              Last Name
            </label>
          </div>
          <input
            value={lastname}
            name="lastname"
            onChange={(e) => setLName(e.target.value)}
            id="lastname"
            required
          />
          <div style={{ marginBottom: "10px" }}>
            <label htmlFor="email" style={{ fontWeight: "normal" }}>
              Email
            </label>
          </div>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            id="email"
            name="email"
            required
            // pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
          />
          <div style={{ marginBottom: "10px" }}>
            <label htmlFor="phone" style={{ fontWeight: "normal" }}>
              Phone
            </label>
          </div>
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            type="tel"
            id="phone"
            name="phone"
            // pattern="[0-9]{10}"
            required
          />

          <label htmlFor="password">Password</label>
          <input
            value={password}
            onChange={(e) => setPass(e.target.value)}
            type="password"
            id="password"
            name="password"
            required
            minLength="1"
          />

          <div className="container">
            <select className="role-dropdown" onChange={handleRoleChange}>
              <option value="">-- Select a Role --</option>
              <option value="user">User</option>
              <option value="washer">Washer</option>

            </select>
          </div>
          <button type="submit">Register</button>
        </form>
      </div>
      <Footer/>
    </div>
  );
};
