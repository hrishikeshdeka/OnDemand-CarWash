import React from 'react';
import { Link} from 'react-router-dom';
import '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Styles/Navbar.css';
import carWashLogo from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Images/Screenshot 2023-07-09 at 1.13.35 AM.png'; 
// import About from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/About.jsx';
// import Contact from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Contact.jsx';
// import { Login } from '/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Login.jsx';
// import { Register } from './Register';

const Navbar = () => {
   
    return (
    <nav className="navbar">
      {/* Left side - Logo and Title */}
      <div className="navbar-left">
        <Link to="/">
          <img
            src={carWashLogo}
            alt="Logo"
            className="navbar-logo"
          />
        </Link>
        <h1 className="navbar-title">Wash Wheels</h1>
      </div>

      {/* Right side - About, Contact, and Login Button */}
      <div className="navbar-right">
        <ul className="navbar-links">
          <li>
            <Link to="/About">About</Link>
          </li>
          <li>
            <Link to="/Contact">Contact</Link>
          </li>
        </ul>
        <Link to="/login" >
          <button className="navbar-login"  style={{ fontSize: '17px', fontWeight: 'bold',borderRadius: '20px' }}>Log in</button>
        </Link>
        <Link to="/register">
          <button className="navbar-register"  style={{ fontSize: '17px', fontWeight: 'bold',borderRadius: '20px' }}>Sign up</button>
        </Link>
      </div>
    </nav>

  
    
    );
  };
  
  export default Navbar;
