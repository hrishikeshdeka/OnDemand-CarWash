import React from "react";
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import { Login } from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Login.jsx";
import { Register } from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/Register.jsx";
import Landing from "./Components/Landing";
import About from "./Components/About";
import Contact from "./Components/Contact";
import UserLanding from "./Components/UserLanding";
import WasherLanding from "./Components/WasherLanding";
import  EditProfile  from "./Components/UserOperations/EditProfile";
import DeletePage from "./Components/UserOperations/DeletePage";
import EditProfileWasher from "./Components/WasherOperations/EditProfileWasher";
import DeleteProfileWasher  from "./Components/WasherOperations/DeleteProfileWasher";
import EditStatus from "./Components/WasherOperations/EditStatus";
import ViewServicesWasher from "./Components/WasherOperations/ViewServicesWasher";
import WasherOrderHistory from "./Components/WasherOperations/WasherOrderHistory";
import BookingOperations from "./Components/UserOperations/BookingOperations";
import GetLatestBookingUser from "./Components/UserOperations/GetLatestBookingUser";
import ViewServicesUser from "./Components/UserOperations/ViewServicesUser";
import InvoiceUser from "./Components/UserOperations/InvoiceUser";
import UserOrderHistory from "./Components/UserOperations/UserOrderHistory";
import PaymentUser from "./Components/UserOperations/PaymentUser";
import AdminLanding from "./Components/AdminLanding";
import ConfirmStatus from "/Users/hrishikesh/Documents/Training/Spring (Backend)/Case Study/Frontend React /on-demand-car-wash/src/Components/UserOperations/ConfirmStatus.jsx";
import ViewUserDetailsAdmin from "./Components/AdminOperations/ViewUserDetailsAdmin";
import ViewWasherDetailsAdmin from "./Components/AdminOperations/ViewWasherDetailsAdmin";
import ViewBookingsAdmin from "./Components/AdminOperations/ViewBookingsAdmin";
import GetEmailByIdAdmin from "./Components/AdminOperations/GetEmailByIdAdmin";
import ManageServices from "./Components/AdminOperations/ManageServices";
import Footer from "./Components/Footer";
import ViewBookingByuserId from "./Components/AdminOperations/ViewBookingByuserId";
import ViewWasherByID from "./Components/AdminOperations/ViewWasherByID";
import EditServices from "./Components/AdminOperations/EditServices";
import ManageProfileUser from "./Components/UserOperations/ManageProfileUser";
import UpdateUser from "./Components/UserOperations/UpdateUser";
import ManageProfileWasher from "./Components/WasherOperations/ManageProfileWasher";
function App() {


  return (
   
    <Router>

      <div className="App">
    
        <Routes>
          <Route path="/" element={<Landing/>} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/about" element={<About/>} />
          <Route path="/contact" element={<Contact/>}/>
          <Route path="/footer" element={<Footer/>}/>
     {/* ROUTING OF USER COMPONENTS */}
          <Route path="/login/user" element={<UserLanding />} />
          <Route path="/login/user/edit" element={<EditProfile />} />
          <Route path="/login/delete/deletepage" element={<DeletePage />}/>
          <Route path ="/login/user/booking-operations" element={<BookingOperations/>}/>
          <Route path ="/login/user/latest-booking" element={<GetLatestBookingUser/>}/>
          <Route path="/login/user/view-services" element={<ViewServicesUser/>}/>
          <Route path="/login/user/invoice-details" element={<InvoiceUser/>}/>
          <Route path="/login/user/user-bookings" element={<UserOrderHistory/>}/>
          <Route path="/login/user/invoice/payment/:bookingId/:washpackPrice" element={<PaymentUser/>}/>
          <Route path="/login/user/invoice/payment/confirm-status" element={<ConfirmStatus/>}/>
          <Route path="/login/user/manage-profile" element={<ManageProfileUser/>}/>
          <Route path="/login/user/manage-profile/update" element={<UpdateUser/>}/>
      {/*ROUTING OF WASHER COMPONENTS */}
      <Route path="/login/washer" element={<WasherLanding />} />
          <Route path="/login/washer/edit" element={<EditProfileWasher />} />
          <Route path="/login/washer/delete" element={<DeleteProfileWasher />}/>
          <Route path="/login/washer/update-status" element={<EditStatus />}/>
          <Route path="/login/washer/washer-services" element={<ViewServicesWasher />}/>
          <Route path="/login/washer/washer-bookings" element={<WasherOrderHistory/>}/>
          <Route path="/login/washer/manage-profile" element={<ManageProfileWasher/>}/> 
      {/*ROUTING OF ADMIN COMPONENTS */}
        <Route path="/login/admin" element={<AdminLanding/>} />
        <Route path="/login/admin/view/user-details" element={<ViewUserDetailsAdmin />} />
        <Route path="/login/admin/view/washer-details" element={<ViewWasherDetailsAdmin />} />
        <Route path="/login/admin/view/booking-details" element={<ViewBookingsAdmin/>}/>
        <Route path="/login/admin/get/email" element={<GetEmailByIdAdmin />}/>
        <Route path="/login/admin/manage/services" element={<ManageServices/>}/>
        <Route path="/login/admin/view-bookings/userId" element={<ViewBookingByuserId/>}/>
        <Route path="/login/admin/view-bookings/washerId" element={<ViewWasherByID/>}/>
        <Route path="/login/admin/manage-services" element={<ManageServices/>}/>
        <Route path="/login/admin/edit-services" element={<EditServices/>}/>
        </Routes>
    
      </div>
    </Router>

  );
}

export default App;

