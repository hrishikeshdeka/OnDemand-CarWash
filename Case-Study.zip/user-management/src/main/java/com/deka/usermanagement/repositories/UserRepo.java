package com.deka.usermanagement.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deka.usermanagement.entities.User;
import com.google.common.base.Optional;

public interface UserRepo extends JpaRepository<User, Integer> {

	// custom operations here.
	User findByBookingId(int bookingId);

}
