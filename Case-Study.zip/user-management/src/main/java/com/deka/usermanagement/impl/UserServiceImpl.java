package com.deka.usermanagement.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deka.usermanagement.entities.User;
import com.deka.usermanagement.exceptions.ResourceNotFoundException;
import com.deka.usermanagement.repositories.UserRepo;
import com.deka.usermanagement.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	private UserRepo userRepository;

	@Override
	public User create(User user) {
		logger.info("Creating user: {}", user);
		return userRepository.save(user);
	}

	@Override
	public List<User> getAll() {
		logger.info("Retrieving all users");
		return userRepository.findAll();
	}

	@Override
	public User getSingle(int uid) {
		logger.info("Retrieving user with ID: {}", uid);
		return userRepository.findById(uid).orElseThrow(() -> {
			logger.error("User not found with ID: {}", uid);
			return new ResourceNotFoundException("User not found with ID: " + uid);
		});
	}

	@Override
	public User update(User user) {
		logger.info("Updating user: {}", user);
		User existingUser = userRepository.findById(user.getUid()).orElseThrow(() -> {
			logger.error("User not found with ID: {}", user.getUid());
			return new ResourceNotFoundException("User not found with ID: " + user.getUid());
		});

		existingUser.setName(user.getName());
		existingUser.setEmail(user.getEmail());
		existingUser.setPassword(user.getPassword());
		existingUser.setBookingId(user.getBookingId());

		return userRepository.save(existingUser);
	}

	@Override
	public void delete(int uid) {
		logger.info("Deleting user with ID: {}", uid);
		userRepository.deleteById(uid);
	}

	@Override
	public User getSingleByBookingId(int bookingId) {
		logger.info("Retrieving user with Booking ID: {}", bookingId);
		User user = userRepository.findByBookingId(bookingId);
		if (user == null) {
			logger.error("User not found with Booking ID: {}", bookingId);
			throw new ResourceNotFoundException("User not found with Booking ID: " + bookingId);
		}
		return user;
	}

}
