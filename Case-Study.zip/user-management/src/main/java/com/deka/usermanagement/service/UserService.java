package com.deka.usermanagement.service;

import java.util.List;

import com.deka.usermanagement.entities.User;

public interface UserService {

	// create
	User create(User user);

	// getAll
	List<User> getAll();

	// getSingle
	User getSingle(int uid);

	// update
	User update(User user);

	// delete
	void delete(int uid);

	// getSingleByBookingId
	User getSingleByBookingId(int bookingId);
}
