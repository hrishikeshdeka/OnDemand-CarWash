package com.deka.usermanagement.controllers;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deka.usermanagement.entities.User;
import com.deka.usermanagement.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService userService;

	@GetMapping("users/all")
	public List<User> getAllUser() {
		logger.info("GET /users/all");
		return userService.getAll();

	}

	@GetMapping("users/{uid}")
	public User getSingleUser(@PathVariable int uid) {
		logger.info("GET /users/" + uid);
		return userService.getSingle(uid);
	}

	@PostMapping("users/signup")
	public User createUser(@RequestBody User user) {
		logger.info("POST /users/signup");
		return userService.create(user);
	}

	@PutMapping("users/profile/{uid}")
	public User updateUser(@PathVariable int uid, @RequestBody User user) {
		logger.info("PUT /users/profile/" + uid);
		user.setUid(uid);
		return userService.update(user);
	}

	@DeleteMapping("users/profile/{uid}")
	public void deleteUser(@PathVariable int uid) {
		logger.info("DELETE /users/profile/" + uid);
		userService.delete(uid);
	}

	@GetMapping("users/booking/{bookingId}")
	public User getUserByBookingId(@PathVariable int bookingId) {
		logger.info("GET /users/booking/" + bookingId);
		return userService.getSingleByBookingId(bookingId);
	}

}
