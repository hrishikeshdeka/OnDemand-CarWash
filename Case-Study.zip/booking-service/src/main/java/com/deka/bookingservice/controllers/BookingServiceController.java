package com.deka.bookingservice.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deka.bookingservice.entities.Bookings;
import com.deka.bookingservice.entities.BookingsDetails;
import com.deka.bookingservice.entities.BookingsWithUser;
import com.deka.bookingservice.entities.BookingsWithWasher;
import com.deka.bookingservice.entities.User;
import com.deka.bookingservice.entities.Washer;
import com.deka.bookingservice.service.BookingService;

@RestController
@RequestMapping("/api")
public class BookingServiceController {

	@Autowired
	private BookingService bookingService;

	@GetMapping("bookings/all")
	public List<Bookings> getAllBookings() {
		return bookingService.getAll();
	}

//	@GetMapping("bookings/{bookingId}")
//	public Bookings getSingleBooking(@PathVariable int bookingId) {
//		return bookingService.getSingle(bookingId);
//	}

	@PostMapping("bookings/new")
	public Bookings createBooking(@RequestBody Bookings bookings) {
		return bookingService.create(bookings);
	}

	@PutMapping("bookings/updateBooking/{bookingId}")
	public Bookings updateBooking(@PathVariable int bookingId, @RequestBody Bookings bookings) {
		return bookingService.update(bookingId, bookings);
	}

	@DeleteMapping("bookings/deleteBooking/{bookingId}")
	public void deleteBooking(@PathVariable int bookingId) {
		bookingService.delete(bookingId);
	}

//	@GetMapping("/bookings/user/{bookingId}")
//	public User getUserByBookingId(@PathVariable int bookingId) {
//		return bookingService.getUserByBookingId(bookingId);
//	}

	// the below code shows the bookings with userid
	@GetMapping("bookings/user/{bookingId}")
	public BookingsWithUser getBookingWithUserDetails(@PathVariable int bookingId) {
		Bookings booking = bookingService.getSingle(bookingId);
		User user = bookingService.getUserWithBookingId(bookingId);

		return new BookingsWithUser(booking, user);
	}

	// the below code shows the washers with bookingId
//	@GetMapping("bookings/washer/{bookingId}")
//	public Washer getSingleWasherByBookingId(@PathVariable int bookingId) {
//		return bookingService.getSingleWasherByBookingId(bookingId);
//	}

	@GetMapping("bookings/washer/{bookingId}")
	public BookingsWithWasher getWasherBookingByBookingId(@PathVariable int bookingId) {
	    Washer washer = bookingService.getSingleWasherByBookingId(bookingId);
	    Bookings booking = bookingService.getSingle(bookingId);
	    return new BookingsWithWasher(booking, washer);
	}

	// the below code shows the bookings with userId and washer
	@GetMapping("bookings/invoice/{bookingId}")
	public BookingsDetails getBookingWithUserAndWasherDetails(@PathVariable int bookingId) {
		Bookings booking = bookingService.getSingle(bookingId);
		User user = bookingService.getUserWithBookingId(bookingId);
		Washer washer = bookingService.getSingleWasherByBookingId(bookingId);

		return new BookingsDetails(booking, user, washer);
	}

}
