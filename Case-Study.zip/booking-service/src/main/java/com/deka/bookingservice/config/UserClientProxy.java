package com.deka.bookingservice.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deka.bookingservice.entities.User;

@FeignClient(name = "USER-MANAGEMENT")
public interface UserClientProxy {

	@GetMapping("/api/users/all")
	public List<User> getAllUser();

	@GetMapping("/api/users/booking/{bookingId}")
	User getUserByBookingId(@PathVariable int bookingId);

//	
//	User getUserByUid(@PathVariable("uid") int uid);

//	
//	@GetMapping("api/users/{uid}")
//	public User getSingleUser(@PathVariable int uid);

}
