package com.deka.bookingservice.entities;

public class BookingsDetails {

	private Bookings booking;
	private User user;
	private Washer washer;

	public Bookings getBooking() {
		return booking;
	}

	public void setBooking(Bookings booking) {
		this.booking = booking;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Washer getWasher() {
		return washer;
	}

	public void setWasher(Washer washer) {
		this.washer = washer;
	}

	public BookingsDetails(Bookings booking, User user, Washer washer) {
		super();
		this.booking = booking;
		this.user = user;
		this.washer = washer;
	}

	public BookingsDetails() {
		super();
	}

}
