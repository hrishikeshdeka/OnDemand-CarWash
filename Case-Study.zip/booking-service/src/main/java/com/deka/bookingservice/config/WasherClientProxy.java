package com.deka.bookingservice.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deka.bookingservice.entities.Washer;

@FeignClient(name = "Washer-Management")
public interface WasherClientProxy {

	@GetMapping("/api/washer/all")
	public List<Washer> getAllWasher();

	@GetMapping("/api/bookings/washer/{bookingId}")
	Washer getSingleWasherByBookingId(@PathVariable("bookingId") int bookingId);

}
