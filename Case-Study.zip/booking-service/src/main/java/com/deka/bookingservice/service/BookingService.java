package com.deka.bookingservice.service;

import java.util.List;

import com.deka.bookingservice.entities.Bookings;
import com.deka.bookingservice.entities.User;
import com.deka.bookingservice.entities.Washer;

public interface BookingService {

	// create
	Bookings create(Bookings bookings);

	// getAll
	List<Bookings> getAll();

	// getSingle
	Bookings getSingle(int bookingId);

	// Delete
	void delete(int bookingId);

	// Update
	Bookings update(int bookingId, Bookings bookings);

	// getSingleByBookingId
//	User getUserByBookingId(int bookingId);

	// getBookingsWithUser
	User getUserWithBookingId(int bookingId);

	// getSingleWasherByBookingId
	Washer getSingleWasherByBookingId(int bookingId);

}
