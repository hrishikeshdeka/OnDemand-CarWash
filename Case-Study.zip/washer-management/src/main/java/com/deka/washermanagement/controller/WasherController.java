package com.deka.washermanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deka.washermanagement.entities.Washer;
import com.deka.washermanagement.service.WasherService;

@RestController
@RequestMapping("/api")
public class WasherController {

	@Autowired
	private WasherService washerService;

	@GetMapping("washer/all")
	public List<Washer> getAllWasher() {
		return washerService.getAll();
	}

	@GetMapping("washer/{wid}")
	public Washer getSingleWasher(@PathVariable String wid) {
		return washerService.getSingle(wid);
	}

	@PostMapping("washer/signup")
	public Washer createWasher(@RequestBody Washer washer) {
		return washerService.create(washer);
	}

	@DeleteMapping("washer/delete/{wid}")
	public void deleteWasher(@PathVariable String wid) {
		washerService.delete(wid);
	}

	@PutMapping("washer/edit/{wid}")
	public Washer updateWasher(@PathVariable String wid, @RequestBody Washer washer) {
		return washerService.update(wid, washer);
	}

	@GetMapping("bookings/washer/{bookingId}")
	public Washer getSingleWasherByBookingId(@PathVariable int bookingId) {
		return washerService.getSingleWasherByBookingId(bookingId);
	}

}
