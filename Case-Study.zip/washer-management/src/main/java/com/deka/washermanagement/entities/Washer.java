package com.deka.washermanagement.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("Washer")
public class Washer {

	@Id
	private String wid;
	private String name;
	private String email;
	private String password;
	private String status;
	private String payload;
	private int bookingId;

	public String getWid() {
		return wid;
	}

	public void setWid(String wid) {
		this.wid = wid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public Washer(String wid, String name, String email, String password, String status, String payload,
			int bookingId) {
		super();
		this.wid = wid;
		this.name = name;
		this.email = email;
		this.password = password;
		this.status = status;
		this.payload = payload;
		this.bookingId = bookingId;
	}

	public Washer() {
		super();
	}

}
