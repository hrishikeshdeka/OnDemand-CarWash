package com.deka.washermanagement.entities;

public class Bookings {

	private int bookingId;
	private String carName;
	private String washPackType;
	private String scheduledate;
	private int uid;
	private String scheduleTime;
	private String address;

	public Bookings(int bookingId, String carName, String washPackType, String scheduledate, int uid,
			String scheduleTime, String address) {
		super();
		this.bookingId = bookingId;
		this.carName = carName;
		this.washPackType = washPackType;
		this.scheduledate = scheduledate;
		this.uid = uid;
		this.scheduleTime = scheduleTime;
		this.address = address;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getWashPackType() {
		return washPackType;
	}

	public void setWashPackType(String washPackType) {
		this.washPackType = washPackType;
	}

	public String getScheduledate() {
		return scheduledate;
	}

	public void setScheduledate(String scheduledate) {
		this.scheduledate = scheduledate;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getScheduleTime() {
		return scheduleTime;
	}

	public void setScheduleTime(String scheduleTime) {
		this.scheduleTime = scheduleTime;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Bookings() {
		super();
	}

//	@Transient
//	@Column(name="Washer_Details")
//	private List<Washer> washer =new ArrayList<>();

}
