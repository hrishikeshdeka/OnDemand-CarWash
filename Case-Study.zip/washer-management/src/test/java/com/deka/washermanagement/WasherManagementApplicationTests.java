package com.deka.washermanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WasherManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
