package com.deka.bookingmanagement.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deka.bookingmanagement.entities.BookingManagement;
import com.deka.bookingmanagement.entities.Bookings;
import com.deka.bookingmanagement.service.BookingManagementService;

@RestController
@RequestMapping("/api")
public class BookingManagementController {

	@Autowired
	private BookingManagementService bookingManagementService;

	@GetMapping("/invoice/all")
	public List<BookingManagement> getAllInvoice() {
		return bookingManagementService.getAll();
	}

	@GetMapping("/invoice/{orderId}")
	public BookingManagement getSingleInvoice(@PathVariable int orderId) {
		return bookingManagementService.getSingle(orderId);
	}

	@PostMapping("/invoice")
	public BookingManagement createInvoice(@RequestBody BookingManagement bookingManagement) {
		return bookingManagementService.create(bookingManagement);
	}

	@PutMapping("/invoice/edit/{orderId}")
	public BookingManagement updateInvoice(@PathVariable int orderId, @RequestBody BookingManagement bookingManagement) {
		return bookingManagementService.update(orderId, bookingManagement);
	}

	@DeleteMapping("/invoice/erase/{orderId}")
	public void deleteInvoice(@PathVariable int orderId) {
		bookingManagementService.delete(orderId);
	}
	
	@GetMapping("/invoice/getBooking/{bookingId}")
	public Bookings retriveBookingsById(@PathVariable int bookingId) {
		return bookingManagementService.retriveBookingsById(bookingId);
	}
}
