package com.deka.bookingmanagement.entities;

public class Invoice {

	private int uid;
	private String wid;
	private String userName;
	private String washerName;
	private int bookingId;
	private String carName;
	private String washPackType;
	private String scheduledate;
	
	

}
