package com.deka.bookingmanagement.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deka.bookingmanagement.entities.BookingManagement;

public interface BookingManagementRepo extends JpaRepository<BookingManagement, Integer>{

	//custom iterations
	
}
