package com.deka.bookingmanagement.service;

import java.util.List;

import com.deka.bookingmanagement.entities.BookingManagement;
import com.deka.bookingmanagement.entities.Bookings;

public interface BookingManagementService {

	// create
	BookingManagement create(BookingManagement bookingManagement);

	// getAll
	
	List<BookingManagement> getAll();
	
	// getSingle
	BookingManagement getSingle(int orderId);
	
	// update
	BookingManagement update(int orderId , BookingManagement bookingManagement);
	
	// delete
	void delete(int orderId);
	
	//getByBookingId
	Bookings retriveBookingsById(int bookingId);
	
	//getUserDetailsById
	
}
