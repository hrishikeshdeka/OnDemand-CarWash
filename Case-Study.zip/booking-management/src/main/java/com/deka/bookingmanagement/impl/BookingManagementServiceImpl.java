package com.deka.bookingmanagement.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.deka.bookingmanagement.entities.BookingManagement;
import com.deka.bookingmanagement.entities.Bookings;
import com.deka.bookingmanagement.exception.ResourceNotFoundException;
import com.deka.bookingmanagement.repositories.BookingManagementRepo;
import com.deka.bookingmanagement.service.BookingManagementService;

@Service
public class BookingManagementServiceImpl implements BookingManagementService {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private BookingManagementRepo bookingManagementRepository;

	@Override
	public BookingManagement create(BookingManagement bookingManagement) {
		return bookingManagementRepository.save(bookingManagement);
	}

	@Override
	public List<BookingManagement> getAll() {

		return bookingManagementRepository.findAll();
	}

	@Override
	public BookingManagement getSingle(int orderId) {

		return bookingManagementRepository.findById(orderId).orElse(null);
	}

	@Override
	public BookingManagement update(int orderId, BookingManagement bookingManagement) {
		BookingManagement existingOrder = bookingManagementRepository.findById(orderId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Booking!"));

		existingOrder.setOrderStatus(bookingManagement.getOrderStatus());

		return bookingManagementRepository.save(existingOrder);
	}

	@Override
	public void delete(int orderId) {

		bookingManagementRepository.deleteById(orderId);
	}

	@Override
	public Bookings retriveBookingsById(int bookingId) {

		Bookings bookings = restTemplate.getForObject("http://localhost:8083/api/bookings/"+bookingId, Bookings.class);
		return bookings;
	}
	

	

}
