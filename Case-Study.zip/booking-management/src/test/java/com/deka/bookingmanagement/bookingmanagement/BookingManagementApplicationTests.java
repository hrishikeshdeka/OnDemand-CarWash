package com.deka.bookingmanagement.bookingmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
